--------------------------------------------------------
--  File created - Thursday-June-17-2021   
--------------------------------------------------------
@F:\ANWESHA_KOSMOS_PRJ\DATAANALYST\TABLES\WLR_EXCHANGE_DATE.sql
@F:\ANWESHA_KOSMOS_PRJ\DATAANALYST\INDEXES\WLR_EXCHANGE_DATE_I1.sql
