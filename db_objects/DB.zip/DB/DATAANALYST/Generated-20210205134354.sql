--------------------------------------------------------
--  File created - Friday-February-05-2021   
--------------------------------------------------------
@F:\Data\DB\Dataanalyst\TABLES\WLR_SERVICEVIEW.sql
@F:\Data\DB\Dataanalyst\INDEXES\WLR_SERVICEVIEW_I11.sql
@F:\Data\DB\Dataanalyst\INDEXES\WLR_SERVICEVIEW_I2.sql
@F:\Data\DB\Dataanalyst\INDEXES\WLR_SERVICEVIEW_PK.sql
@F:\Data\DB\Dataanalyst\CONSTRAINTS\WLR_SERVICEVIEW.sql
