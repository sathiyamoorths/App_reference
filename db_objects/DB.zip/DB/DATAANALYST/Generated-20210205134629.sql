--------------------------------------------------------
--  File created - Friday-February-05-2021   
--------------------------------------------------------
@F:\Data\DB\Dataanalyst\TABLES\WLR_EDGE_SERVICE_T.sql
@F:\Data\DB\Dataanalyst\INDEXES\WLR_EDGE_SERVICE_T_I1.sql
@F:\Data\DB\Dataanalyst\INDEXES\WLR_EDGE_SERVICE_T_I2.sql
