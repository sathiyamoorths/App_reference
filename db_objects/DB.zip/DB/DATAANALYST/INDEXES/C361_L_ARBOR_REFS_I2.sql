--------------------------------------------------------
--  DDL for Index C361_L_ARBOR_REFS_I2
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."C361_L_ARBOR_REFS_I2" ON "DATAANALYST"."C361_L_ARBOR_REFS" ("EXTERNAL_ID") 
  ;
