--------------------------------------------------------
--  DDL for Index AKJ_GAMMA_SIP_ALL_INDEX1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AKJ_GAMMA_SIP_ALL_INDEX1" ON "DATAANALYST"."AKJ_GAMMA_SIP_ALL" ("ENDPOINT") 
  ;
