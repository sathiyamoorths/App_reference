--------------------------------------------------------
--  DDL for Index ADDRESS_GROUP_TEMP_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."ADDRESS_GROUP_TEMP_I1" ON "DATAANALYST"."ADDRESS_GROUP_TEMP" ("LOCATNID") 
  ;
