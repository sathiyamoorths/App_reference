--------------------------------------------------------
--  DDL for Index DIA_CLARFY_SERV_I2
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."DIA_CLARFY_SERV_I2" ON "DATAANALYST"."DIA_CLARIFY_SERV" ("CLARIFY_SERVICE") 
  ;
