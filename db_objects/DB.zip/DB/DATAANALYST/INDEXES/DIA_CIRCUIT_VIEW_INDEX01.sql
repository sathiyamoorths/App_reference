--------------------------------------------------------
--  DDL for Index DIA_CIRCUIT_VIEW_INDEX01
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."DIA_CIRCUIT_VIEW_INDEX01" ON "DATAANALYST"."DIA_CIRCUIT_VIEW" ("PRT_SERVICEID") 
  ;
