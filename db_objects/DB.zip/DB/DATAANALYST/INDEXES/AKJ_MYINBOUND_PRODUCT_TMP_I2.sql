--------------------------------------------------------
--  DDL for Index AKJ_MYINBOUND_PRODUCT_TMP_I2
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AKJ_MYINBOUND_PRODUCT_TMP_I2" ON "DATAANALYST"."AKJ_MYINBOUND_PRODUCT_TMP" ("LASTEIGHT") 
  ;
