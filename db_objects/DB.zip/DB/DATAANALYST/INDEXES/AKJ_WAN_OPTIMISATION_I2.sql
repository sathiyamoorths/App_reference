--------------------------------------------------------
--  DDL for Index AKJ_WAN_OPTIMISATION_I2
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AKJ_WAN_OPTIMISATION_I2" ON "DATAANALYST"."AKJ_WAN_OPTIMISATION" ("SUPPLIER_PRODUCT_REFERENCE") 
  ;
