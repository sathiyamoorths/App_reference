--------------------------------------------------------
--  DDL for Index AKJ_ETHERNET_INDEX5
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AKJ_ETHERNET_INDEX5" ON "DATAANALYST"."AKJ_ETHERNET" ("SITEID") 
  ;
