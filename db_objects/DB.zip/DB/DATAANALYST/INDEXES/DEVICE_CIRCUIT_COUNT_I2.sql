--------------------------------------------------------
--  DDL for Index DEVICE_CIRCUIT_COUNT_I2
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."DEVICE_CIRCUIT_COUNT_I2" ON "DATAANALYST"."DEVICE_CIRCUIT_COUNT" ("LOCATIONID") 
  ;
