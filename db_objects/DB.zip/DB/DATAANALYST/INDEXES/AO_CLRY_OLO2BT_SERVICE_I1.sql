--------------------------------------------------------
--  DDL for Index AO_CLRY_OLO2BT_SERVICE_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AO_CLRY_OLO2BT_SERVICE_I1" ON "DATAANALYST"."AO_CLRY_OLO2BT_SERVICE" ("CLEAN_OLO_REF") 
  ;
