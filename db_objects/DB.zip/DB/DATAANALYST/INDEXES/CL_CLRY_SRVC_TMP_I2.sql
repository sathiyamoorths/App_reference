--------------------------------------------------------
--  DDL for Index CL_CLRY_SRVC_TMP_I2
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CL_CLRY_SRVC_TMP_I2" ON "DATAANALYST"."CL_CLRY_SRVC_TMP" ("S_SERIAL_NO") 
  ;
