--------------------------------------------------------
--  DDL for Index APM_KENAN_TEMP_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."APM_KENAN_TEMP_I1" ON "DATAANALYST"."APM_KENAN_TEMP" ("SERVICE_ID") 
  ;
