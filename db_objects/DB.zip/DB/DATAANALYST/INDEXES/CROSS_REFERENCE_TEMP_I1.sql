--------------------------------------------------------
--  DDL for Index CROSS_REFERENCE_TEMP_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CROSS_REFERENCE_TEMP_I1" ON "DATAANALYST"."CROSS_REFERENCE_TEMP" ("CIRCUITNAME") 
  ;
