--------------------------------------------------------
--  DDL for Index AKJ_ETHERNET_INDEX2
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AKJ_ETHERNET_INDEX2" ON "DATAANALYST"."AKJ_ETHERNET" ("SUPPLIER_PRODUCT_REFERENCE") 
  ;
