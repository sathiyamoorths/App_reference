--------------------------------------------------------
--  DDL for Index APM_SERVICEVIEW_TEMP_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."APM_SERVICEVIEW_TEMP_I1" ON "DATAANALYST"."APM_SERVICEVIEW_TEMP" ("SERVICE_ID") 
  ;
