--------------------------------------------------------
--  DDL for Index CTETHR_CLARIFY_SERV_INDEX1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CTETHR_CLARIFY_SERV_INDEX1" ON "DATAANALYST"."CITY_ETHERNET_CLARIFY_SERV" ("CLARIFY_CIRCUIT_NAME") 
  ;
