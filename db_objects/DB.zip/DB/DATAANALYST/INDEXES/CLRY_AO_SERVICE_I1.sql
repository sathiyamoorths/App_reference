--------------------------------------------------------
--  DDL for Index CLRY_AO_SERVICE_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CLRY_AO_SERVICE_I1" ON "DATAANALYST"."CLRY_AO_SERVICE_MAPPING" ("SERVICE_OBJID") 
  ;
