--------------------------------------------------------
--  DDL for Index AMDOCS_ORDER_DETAILS_I2
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AMDOCS_ORDER_DETAILS_I2" ON "DATAANALYST"."AMDOCS_ORDER_DETAILS" ("SERVICE_ID") 
  ;
