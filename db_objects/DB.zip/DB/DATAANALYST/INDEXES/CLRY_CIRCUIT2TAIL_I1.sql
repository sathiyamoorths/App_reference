--------------------------------------------------------
--  DDL for Index CLRY_CIRCUIT2TAIL_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CLRY_CIRCUIT2TAIL_I1" ON "DATAANALYST"."CLRY_CIRCUIT2TAIL" ("CIRCUIT_NAME") 
  ;
