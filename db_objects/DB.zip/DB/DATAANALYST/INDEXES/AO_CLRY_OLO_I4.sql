--------------------------------------------------------
--  DDL for Index AO_CLRY_OLO_I4
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AO_CLRY_OLO_I4" ON "DATAANALYST"."AO_CLRY_OLO" ("HOW_ADDED") 
  ;
