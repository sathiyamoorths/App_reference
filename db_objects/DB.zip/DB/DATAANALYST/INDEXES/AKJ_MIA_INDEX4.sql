--------------------------------------------------------
--  DDL for Index AKJ_MIA_INDEX4
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AKJ_MIA_INDEX4" ON "DATAANALYST"."AKJ_MIA" ("SUPPLIER_PRODUCT_REF_CLEAN") 
  ;
