--------------------------------------------------------
--  DDL for Index CRM_SERVICEVIEW_DRIV0_TMP_I
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CRM_SERVICEVIEW_DRIV0_TMP_I" ON "DATAANALYST"."CRM_SERVICEVIEW_DRIV0_TMP" ("PRT_SERVICE_ID") 
  ;
