--------------------------------------------------------
--  DDL for Index AKJ_PRT_U_SERVICEVIEW_INDEX5
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AKJ_PRT_U_SERVICEVIEW_INDEX5" ON "DATAANALYST"."AKJ_PRT_U_SERVICEVIEW" ("INVENTORY_CIRCUIT_REFS") 
  ;
