--------------------------------------------------------
--  DDL for Index AS2529_UNO_DATA_ID2
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AS2529_UNO_DATA_ID2" ON "DATAANALYST"."AS2529_UNO_DATA" ("SERVICEREF") 
  ;
