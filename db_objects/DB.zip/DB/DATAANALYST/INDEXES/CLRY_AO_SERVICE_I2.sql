--------------------------------------------------------
--  DDL for Index CLRY_AO_SERVICE_I2
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CLRY_AO_SERVICE_I2" ON "DATAANALYST"."CLRY_AO_SERVICE_MAPPING" ("AO_LINKID") 
  ;
