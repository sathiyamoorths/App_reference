--------------------------------------------------------
--  DDL for Index DIA_CLARIFY_SERV_INDEX2
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."DIA_CLARIFY_SERV_INDEX2" ON "DATAANALYST"."DIA_CLARIFY_SERV" ("CLARIFY_CIRCUIT_TYPE") 
  ;
