--------------------------------------------------------
--  DDL for Index AKJ_PRT_U_DDI_RANGES_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AKJ_PRT_U_DDI_RANGES_I1" ON "DATAANALYST"."AKJ_PRT_U_DDI_RANGES" ("LINKID") 
  ;
