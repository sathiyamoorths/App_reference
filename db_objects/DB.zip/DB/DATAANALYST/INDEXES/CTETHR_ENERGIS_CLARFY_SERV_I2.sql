--------------------------------------------------------
--  DDL for Index CTETHR_ENERGIS_CLARFY_SERV_I2
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CTETHR_ENERGIS_CLARFY_SERV_I2" ON "DATAANALYST"."CITY_ETHERNET_CLARIFY_SERV" ("CLARIFY_SERVICE") 
  ;
