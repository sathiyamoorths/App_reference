--------------------------------------------------------
--  DDL for Index CONTACT_LITE_SERVICE_VIEW_I2
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CONTACT_LITE_SERVICE_VIEW_I2" ON "DATAANALYST"."CONTACT_LITE_SERVICE_VIEW" ("SERVICE_ID") 
  ;
