--------------------------------------------------------
--  DDL for Index AS2529_THUSSF_ASSOCIATED_ID
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AS2529_THUSSF_ASSOCIATED_ID" ON "DATAANALYST"."THUSSF_ASSOCIATED_ORDERS" ("ID") 
  ;
