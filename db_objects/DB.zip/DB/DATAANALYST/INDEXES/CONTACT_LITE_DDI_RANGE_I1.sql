--------------------------------------------------------
--  DDL for Index CONTACT_LITE_DDI_RANGE_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CONTACT_LITE_DDI_RANGE_I1" ON "DATAANALYST"."CONTACT_LITE_DDI_RANGE" ("PRT_SERVICEID") 
  ;
