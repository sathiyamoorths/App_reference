--------------------------------------------------------
--  DDL for Index CLEAN_BILLING_ACCOUNT_I2
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CLEAN_BILLING_ACCOUNT_I2" ON "DATAANALYST"."CLEAN_BILLING_ACCOUNT_NO" ("UPDATED_BILLING_ACC_NO") 
  ;
