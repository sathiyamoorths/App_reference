--------------------------------------------------------
--  DDL for Index CLRY_SERVICES_I6
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CLRY_SERVICES_I6" ON "DATAANALYST"."CLRY_SERVICES" ("A_END_SITE_OBJID") 
  ;
