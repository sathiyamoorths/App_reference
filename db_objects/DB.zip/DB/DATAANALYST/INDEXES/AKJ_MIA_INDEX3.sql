--------------------------------------------------------
--  DDL for Index AKJ_MIA_INDEX3
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AKJ_MIA_INDEX3" ON "DATAANALYST"."AKJ_MIA" ("CLI") 
  ;
