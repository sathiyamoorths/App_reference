--------------------------------------------------------
--  DDL for Index AMDOCS_ORDERING_CIRCUITS_I2
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AMDOCS_ORDERING_CIRCUITS_I2" ON "DATAANALYST"."AMDOCS_ORDERING_CIRCUITS" ("LINKID") 
  ;
