--------------------------------------------------------
--  DDL for Index AS2529_SERVICE_ID_TEMP_I3
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AS2529_SERVICE_ID_TEMP_I3" ON "DATAANALYST"."AS2529_SERVICE_ID_TEMP" ("SUBSTR2") 
  ;
