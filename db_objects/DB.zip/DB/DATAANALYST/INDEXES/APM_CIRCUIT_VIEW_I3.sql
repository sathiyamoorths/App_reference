--------------------------------------------------------
--  DDL for Index APM_CIRCUIT_VIEW_I3
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."APM_CIRCUIT_VIEW_I3" ON "DATAANALYST"."APM_CIRCUIT_VIEW" ("LINKID") 
  ;
