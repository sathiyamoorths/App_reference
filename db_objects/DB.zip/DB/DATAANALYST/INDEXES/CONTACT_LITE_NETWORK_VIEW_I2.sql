--------------------------------------------------------
--  DDL for Index CONTACT_LITE_NETWORK_VIEW_I2
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CONTACT_LITE_NETWORK_VIEW_I2" ON "DATAANALYST"."CONTACT_LITE_NETWORK_VIEW" ("PRT_SERVICEID") 
  ;
