--------------------------------------------------------
--  DDL for Index BILLING_DETAILS_TEMP_T2
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."BILLING_DETAILS_TEMP_T2" ON "DATAANALYST"."BILLING_DETAILS_TEMP" ("BILLING_SYSTEM") 
  ;
