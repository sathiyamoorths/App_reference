--------------------------------------------------------
--  DDL for Index CLRY_CASES_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CLRY_CASES_I1" ON "DATAANALYST"."CLRY_CASES" ("SERVICE_OBJID") 
  ;
