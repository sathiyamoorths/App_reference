--------------------------------------------------------
--  DDL for Index CRM_SERVICEVIEW_DRIV_I2
--------------------------------------------------------

  CREATE BITMAP INDEX "DATAANALYST"."CRM_SERVICEVIEW_DRIV_I2" ON "DATAANALYST"."CRM_SERVICEVIEW_DRIV" ("LVL_IND") 
  ;
