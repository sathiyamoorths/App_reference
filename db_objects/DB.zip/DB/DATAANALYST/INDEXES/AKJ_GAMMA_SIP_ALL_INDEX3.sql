--------------------------------------------------------
--  DDL for Index AKJ_GAMMA_SIP_ALL_INDEX3
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AKJ_GAMMA_SIP_ALL_INDEX3" ON "DATAANALYST"."AKJ_GAMMA_SIP_ALL" ("END_POINT_3") 
  ;
