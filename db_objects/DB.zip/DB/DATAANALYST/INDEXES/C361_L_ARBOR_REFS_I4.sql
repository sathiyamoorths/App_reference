--------------------------------------------------------
--  DDL for Index C361_L_ARBOR_REFS_I4
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."C361_L_ARBOR_REFS_I4" ON "DATAANALYST"."C361_L_ARBOR_REFS" ("REF_TYPE") 
  ;
