--------------------------------------------------------
--  DDL for Index CRM_SERVICEVIEW_ONTOLOGY_I
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CRM_SERVICEVIEW_ONTOLOGY_I" ON "DATAANALYST"."CRM_SERVICEVIEW_ONTOLOGY" ("SERVICE_ID") 
  ;
