--------------------------------------------------------
--  DDL for Index AKJ_MPLS_INDEX4
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AKJ_MPLS_INDEX4" ON "DATAANALYST"."AKJ_MPLS" ("SITEID") 
  ;
