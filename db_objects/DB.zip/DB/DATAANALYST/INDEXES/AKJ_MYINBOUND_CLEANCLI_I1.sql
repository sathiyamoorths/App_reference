--------------------------------------------------------
--  DDL for Index AKJ_MYINBOUND_CLEANCLI_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AKJ_MYINBOUND_CLEANCLI_I1" ON "DATAANALYST"."AKJ_MYINBOUND_CLEANCLI" ("CLEAN_CLI") 
  ;
