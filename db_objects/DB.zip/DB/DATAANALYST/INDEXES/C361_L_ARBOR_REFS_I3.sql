--------------------------------------------------------
--  DDL for Index C361_L_ARBOR_REFS_I3
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."C361_L_ARBOR_REFS_I3" ON "DATAANALYST"."C361_L_ARBOR_REFS" ("CLEAN_REF") 
  ;
