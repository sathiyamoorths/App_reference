--------------------------------------------------------
--  DDL for Index APM_CIRCUIT_VIEW_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."APM_CIRCUIT_VIEW_I1" ON "DATAANALYST"."APM_CIRCUIT_VIEW" ("PRT_SERVICEID") 
  ;
