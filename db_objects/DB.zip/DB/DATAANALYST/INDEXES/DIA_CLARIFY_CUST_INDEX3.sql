--------------------------------------------------------
--  DDL for Index DIA_CLARIFY_CUST_INDEX3
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."DIA_CLARIFY_CUST_INDEX3" ON "DATAANALYST"."DIA_CLARIFY_CUST" ("BILLING_CUSTID") 
  ;
