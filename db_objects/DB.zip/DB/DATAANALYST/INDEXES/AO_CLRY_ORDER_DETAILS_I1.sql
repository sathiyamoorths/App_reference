--------------------------------------------------------
--  DDL for Index AO_CLRY_ORDER_DETAILS_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AO_CLRY_ORDER_DETAILS_I1" ON "DATAANALYST"."AO_CLRY_ORDER_DETAILS" ("SERVICE_ID") 
  ;
