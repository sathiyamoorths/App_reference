--------------------------------------------------------
--  DDL for Index AKJ_OVERRIDE_DETAILS_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "DATAANALYST"."AKJ_OVERRIDE_DETAILS_PK" ON "DATAANALYST"."AKJ_OVERRIDE_DETAILS" ("EXISTING_VALUE", "SERVICE_ID") 
  ;
