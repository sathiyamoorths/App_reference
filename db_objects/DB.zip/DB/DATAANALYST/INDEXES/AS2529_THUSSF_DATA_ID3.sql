--------------------------------------------------------
--  DDL for Index AS2529_THUSSF_DATA_ID3
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AS2529_THUSSF_DATA_ID3" ON "DATAANALYST"."AS2529_THUSSF_DATA" ("CLEANED_HOSTNAME") 
  ;
