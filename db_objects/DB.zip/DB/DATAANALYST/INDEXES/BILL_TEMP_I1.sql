--------------------------------------------------------
--  DDL for Index BILL_TEMP_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."BILL_TEMP_I1" ON "DATAANALYST"."MAGUIRE_CRM6_BILLING_TEMP" ("SERVICE_ID") 
  ;
