--------------------------------------------------------
--  DDL for Index C361_L_ARBOR_REFS_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."C361_L_ARBOR_REFS_I1" ON "DATAANALYST"."C361_L_ARBOR_REFS" ("SUBSCR_NO") 
  ;
