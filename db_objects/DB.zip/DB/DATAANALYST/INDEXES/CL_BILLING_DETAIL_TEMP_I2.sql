--------------------------------------------------------
--  DDL for Index CL_BILLING_DETAIL_TEMP_I2
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CL_BILLING_DETAIL_TEMP_I2" ON "DATAANALYST"."CL_BILLING_DETAIL_TEMP" ("ACC_ACCOUNT_NUMBER") 
  ;
