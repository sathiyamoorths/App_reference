--------------------------------------------------------
--  DDL for Index CRM_IN_111
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CRM_IN_111" ON "DATAANALYST"."OPTICAL_CRM_TOP_CIRCUITS" ("REF_TOP_CIRCUIT") 
  ;
