--------------------------------------------------------
--  DDL for Index AMDOCS_ORDER_DETAILS_I3
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AMDOCS_ORDER_DETAILS_I3" ON "DATAANALYST"."AMDOCS_ORDER_DETAILS" ("VODAFONE_ORDER_REF") 
  ;
