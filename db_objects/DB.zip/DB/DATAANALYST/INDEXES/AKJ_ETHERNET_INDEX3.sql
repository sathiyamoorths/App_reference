--------------------------------------------------------
--  DDL for Index AKJ_ETHERNET_INDEX3
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AKJ_ETHERNET_INDEX3" ON "DATAANALYST"."AKJ_ETHERNET" ("CLI") 
  ;
