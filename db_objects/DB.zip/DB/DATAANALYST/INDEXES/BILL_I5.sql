--------------------------------------------------------
--  DDL for Index BILL_I5
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."BILL_I5" ON "DATAANALYST"."MAGUIRE_CRM6_BILLING_DETAIL_2" ("SOURCE_SYSTEM") 
  ;
