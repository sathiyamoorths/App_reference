--------------------------------------------------------
--  DDL for Index C361_CLRY_SERVICE1_I2
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."C361_CLRY_SERVICE1_I2" ON "DATAANALYST"."C361_CLRY_SERVICE1" ("SERVICE_OBJID") 
  ;
