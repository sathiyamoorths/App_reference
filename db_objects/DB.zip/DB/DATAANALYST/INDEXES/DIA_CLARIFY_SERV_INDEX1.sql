--------------------------------------------------------
--  DDL for Index DIA_CLARIFY_SERV_INDEX1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."DIA_CLARIFY_SERV_INDEX1" ON "DATAANALYST"."DIA_CLARIFY_SERV" ("CLARIFY_CIRCUIT_NAME") 
  ;
