--------------------------------------------------------
--  DDL for Index CLRY_SERVICES_I2
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CLRY_SERVICES_I2" ON "DATAANALYST"."CLRY_SERVICES" ("S_SERIAL_NO") 
  ;
