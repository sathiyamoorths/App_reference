--------------------------------------------------------
--  DDL for Index CLRY_ALL_PRODUCTS_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CLRY_ALL_PRODUCTS_I1" ON "DATAANALYST"."CLRY_ALL_PRODUCTS" ("PART_OBJID") 
  ;
