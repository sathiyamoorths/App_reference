--------------------------------------------------------
--  DDL for Index CLRY_AO_CIRCUIT_I2
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CLRY_AO_CIRCUIT_I2" ON "DATAANALYST"."CLRY_AO_CIRCUIT_MAPPING" ("SERVICE_ID") 
  ;
