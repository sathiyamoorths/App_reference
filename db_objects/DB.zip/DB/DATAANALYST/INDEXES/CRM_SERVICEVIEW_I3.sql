--------------------------------------------------------
--  DDL for Index CRM_SERVICEVIEW_I3
--------------------------------------------------------

  CREATE BITMAP INDEX "DATAANALYST"."CRM_SERVICEVIEW_I3" ON "DATAANALYST"."CRM_SERVICEVIEW" ("PACKAGE_NAME") 
  ;
