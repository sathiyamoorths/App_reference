--------------------------------------------------------
--  DDL for Index CL_DMS_NUMBER_RANGES_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CL_DMS_NUMBER_RANGES_I1" ON "DATAANALYST"."CL_DMS_NUMBER_RANGES" ("START_NUMBER") 
  ;
