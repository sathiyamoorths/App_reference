--------------------------------------------------------
--  DDL for Index BIV_CLARIFY_TEMP_PIDS_INDEX1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."BIV_CLARIFY_TEMP_PIDS_INDEX1" ON "DATAANALYST"."IV_BLUE_CLARIFY_TEMP_PIDS" ("CLI") 
  ;
