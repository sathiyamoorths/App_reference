--------------------------------------------------------
--  DDL for Index AMD_ORDERING_SERVICES_I2
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AMD_ORDERING_SERVICES_I2" ON "DATAANALYST"."AMDOCS_ORDERING_SERVICES" ("SERVICE_ID") 
  ;
