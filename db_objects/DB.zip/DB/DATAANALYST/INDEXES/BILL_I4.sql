--------------------------------------------------------
--  DDL for Index BILL_I4
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."BILL_I4" ON "DATAANALYST"."MAGUIRE_CRM6_BILLING_DETAIL_2" ("BILLING_CUSTOMER") 
  ;
