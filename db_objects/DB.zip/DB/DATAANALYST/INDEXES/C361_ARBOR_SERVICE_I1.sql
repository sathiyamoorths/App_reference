--------------------------------------------------------
--  DDL for Index C361_ARBOR_SERVICE_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."C361_ARBOR_SERVICE_I1" ON "DATAANALYST"."C361_ARBOR_SERVICE" ("SUBSCR_NO") 
  ;
