--------------------------------------------------------
--  DDL for Index AKJ_PRT_U_SERVICE3
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AKJ_PRT_U_SERVICE3" ON "DATAANALYST"."AKJ_PRT_U_SERVICEVIEW_TEMP" ("SERVICE_ID") 
  ;
