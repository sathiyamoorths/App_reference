--------------------------------------------------------
--  DDL for Index CUSTOMERS_INDEX1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CUSTOMERS_INDEX1" ON "DATAANALYST"."CUSTOMERS" ("CUSTOMER_ID") 
  ;
