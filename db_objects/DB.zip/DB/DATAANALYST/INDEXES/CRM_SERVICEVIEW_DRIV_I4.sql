--------------------------------------------------------
--  DDL for Index CRM_SERVICEVIEW_DRIV_I4
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CRM_SERVICEVIEW_DRIV_I4" ON "DATAANALYST"."CRM_SERVICEVIEW_DRIV" ("PRT_SERVICE_ID") 
  ;
