--------------------------------------------------------
--  DDL for Index AKJ_ETHERNET_INDEX4
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AKJ_ETHERNET_INDEX4" ON "DATAANALYST"."AKJ_ETHERNET" ("SUPPLIER_PRODUCT_REF_CLEAN") 
  ;
