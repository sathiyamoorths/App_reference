--------------------------------------------------------
--  DDL for Index AS2529_SERVICE_VW_INDX2
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AS2529_SERVICE_VW_INDX2" ON "DATAANALYST"."AS2529_SERVICE_VIEW" ("LINKID") 
  ;
