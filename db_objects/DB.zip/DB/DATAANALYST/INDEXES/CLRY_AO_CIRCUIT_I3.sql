--------------------------------------------------------
--  DDL for Index CLRY_AO_CIRCUIT_I3
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CLRY_AO_CIRCUIT_I3" ON "DATAANALYST"."CLRY_AO_CIRCUIT_MAPPING" ("AO_LINKID") 
  ;
