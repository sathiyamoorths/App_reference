--------------------------------------------------------
--  DDL for Index DIA_CLEAN_CIRCUIT_REF_INDEX1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."DIA_CLEAN_CIRCUIT_REF_INDEX1" ON "DATAANALYST"."DIA_CLEAN_CIRCUIT_REF" ("CLEAN_CIRCUIT_REFERENCE") 
  ;
