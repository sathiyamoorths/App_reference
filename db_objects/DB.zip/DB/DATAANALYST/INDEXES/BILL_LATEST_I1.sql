--------------------------------------------------------
--  DDL for Index BILL_LATEST_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."BILL_LATEST_I1" ON "DATAANALYST"."MAGUIRE_CRM6_BILL_LATEST" ("SERVICE_ID") 
  ;
