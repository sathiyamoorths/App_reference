--------------------------------------------------------
--  DDL for Index AMDOCS_ORDERING_CKT_ALL_I3
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AMDOCS_ORDERING_CKT_ALL_I3" ON "DATAANALYST"."AMDOCS_ORDERING_CIRCUITS_ALL" ("CIRCUIT_ID") 
  ;
