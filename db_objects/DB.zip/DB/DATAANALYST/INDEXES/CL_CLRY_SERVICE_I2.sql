--------------------------------------------------------
--  DDL for Index CL_CLRY_SERVICE_I2
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CL_CLRY_SERVICE_I2" ON "DATAANALYST"."CL_CLRY_SERVICE" ("S_SERIAL_NO") 
  ;
