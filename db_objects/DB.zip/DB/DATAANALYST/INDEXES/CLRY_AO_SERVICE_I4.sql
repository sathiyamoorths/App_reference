--------------------------------------------------------
--  DDL for Index CLRY_AO_SERVICE_I4
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CLRY_AO_SERVICE_I4" ON "DATAANALYST"."CLRY_AO_SERVICE_MAPPING" ("S_SERIAL_NO") 
  ;
