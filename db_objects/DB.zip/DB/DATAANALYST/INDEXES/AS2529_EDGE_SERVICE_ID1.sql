--------------------------------------------------------
--  DDL for Index AS2529_EDGE_SERVICE_ID1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AS2529_EDGE_SERVICE_ID1" ON "DATAANALYST"."AS2529_EDGE_SERVICE" ("MATCHEDVALUE") 
  ;
