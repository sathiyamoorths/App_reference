--------------------------------------------------------
--  DDL for Index AKJ_CLEAN_REFS_INDEX1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AKJ_CLEAN_REFS_INDEX1" ON "DATAANALYST"."AKJ_CLEAN_REFS" ("REFERENCE_") 
  ;
