--------------------------------------------------------
--  DDL for Index CL_DMS_NUMBER_RANGES_I2
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CL_DMS_NUMBER_RANGES_I2" ON "DATAANALYST"."CL_DMS_NUMBER_RANGES" ("END_NUMBER") 
  ;
