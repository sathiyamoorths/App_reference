--------------------------------------------------------
--  DDL for Index AMD_ORDERING_SERVICES_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AMD_ORDERING_SERVICES_I1" ON "DATAANALYST"."AMDOCS_ORDERING_SERVICES" ("LINKID") 
  ;
