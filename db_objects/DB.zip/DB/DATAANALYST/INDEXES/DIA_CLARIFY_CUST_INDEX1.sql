--------------------------------------------------------
--  DDL for Index DIA_CLARIFY_CUST_INDEX1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."DIA_CLARIFY_CUST_INDEX1" ON "DATAANALYST"."DIA_CLARIFY_CUST" ("CONTRACTUAL_CUSTID") 
  ;
