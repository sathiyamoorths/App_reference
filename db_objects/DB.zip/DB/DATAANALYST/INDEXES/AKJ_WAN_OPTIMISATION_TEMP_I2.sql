--------------------------------------------------------
--  DDL for Index AKJ_WAN_OPTIMISATION_TEMP_I2
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AKJ_WAN_OPTIMISATION_TEMP_I2" ON "DATAANALYST"."AKJ_WAN_OPTIMISATION_TEMP" ("SUPPLIER_PRODUCT_REFERENCE") 
  ;
