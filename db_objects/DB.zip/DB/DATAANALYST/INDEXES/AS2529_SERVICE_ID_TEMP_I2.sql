--------------------------------------------------------
--  DDL for Index AS2529_SERVICE_ID_TEMP_I2
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AS2529_SERVICE_ID_TEMP_I2" ON "DATAANALYST"."AS2529_SERVICE_ID_TEMP" ("SUBSTR1") 
  ;
