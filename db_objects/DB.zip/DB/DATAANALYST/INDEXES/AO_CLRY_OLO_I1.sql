--------------------------------------------------------
--  DDL for Index AO_CLRY_OLO_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AO_CLRY_OLO_I1" ON "DATAANALYST"."AO_CLRY_OLO" ("OLO_REF") 
  ;
