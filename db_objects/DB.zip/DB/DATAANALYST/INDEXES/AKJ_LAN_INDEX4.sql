--------------------------------------------------------
--  DDL for Index AKJ_LAN_INDEX4
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AKJ_LAN_INDEX4" ON "DATAANALYST"."AKJ_LAN" ("SUPPLIER_PRODUCT_REF_CLEAN") 
  ;
