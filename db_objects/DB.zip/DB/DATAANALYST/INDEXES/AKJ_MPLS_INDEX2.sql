--------------------------------------------------------
--  DDL for Index AKJ_MPLS_INDEX2
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AKJ_MPLS_INDEX2" ON "DATAANALYST"."AKJ_MPLS" ("SUPPLIER_PRODUCT_REFERENCE") 
  ;
