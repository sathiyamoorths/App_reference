--------------------------------------------------------
--  DDL for Index AKJ_MYINBOUND_PRODUCT_TMP_I3
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AKJ_MYINBOUND_PRODUCT_TMP_I3" ON "DATAANALYST"."AKJ_MYINBOUND_PRODUCT_TMP" ("CLI") 
  ;
