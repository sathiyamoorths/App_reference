--------------------------------------------------------
--  DDL for Index AKJ_MIA_INDEX5
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AKJ_MIA_INDEX5" ON "DATAANALYST"."AKJ_MIA" ("SITEID") 
  ;
