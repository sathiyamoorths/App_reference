--------------------------------------------------------
--  DDL for Index AKJ_PRT_U_SERVICEVIEW_INDEX1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AKJ_PRT_U_SERVICEVIEW_INDEX1" ON "DATAANALYST"."AKJ_PRT_U_SERVICEVIEW" ("LEGACY_NAME") 
  ;
