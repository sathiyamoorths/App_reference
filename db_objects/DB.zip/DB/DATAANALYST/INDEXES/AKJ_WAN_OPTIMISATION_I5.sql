--------------------------------------------------------
--  DDL for Index AKJ_WAN_OPTIMISATION_I5
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AKJ_WAN_OPTIMISATION_I5" ON "DATAANALYST"."AKJ_WAN_OPTIMISATION" ("SITEID") 
  ;
