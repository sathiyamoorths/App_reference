--------------------------------------------------------
--  DDL for Index AKJ_WAN_OPTIMISATION_TEMP_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AKJ_WAN_OPTIMISATION_TEMP_I1" ON "DATAANALYST"."AKJ_WAN_OPTIMISATION_TEMP" ("PRODUCTDESCRIPTION") 
  ;
