--------------------------------------------------------
--  DDL for Index CLRY_SERVICES1_I2
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CLRY_SERVICES1_I2" ON "DATAANALYST"."CLRY_SERVICES1" ("SERVICE_OBJID") 
  ;
