--------------------------------------------------------
--  DDL for Index DIA_CLARIFY_SERV_INDEX33
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."DIA_CLARIFY_SERV_INDEX33" ON "DATAANALYST"."DIA_CLARIFY_SERV" ("CLEAN_CIRCUIT_NAME") 
  ;
