--------------------------------------------------------
--  DDL for Index BDOG_EDGE_SERVICE_INDEX1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."BDOG_EDGE_SERVICE_INDEX1" ON "DATAANALYST"."BDOG_EDGE_SERVICE" ("SERVICE_ID") 
  ;
