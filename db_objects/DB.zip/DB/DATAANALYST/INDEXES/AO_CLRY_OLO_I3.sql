--------------------------------------------------------
--  DDL for Index AO_CLRY_OLO_I3
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AO_CLRY_OLO_I3" ON "DATAANALYST"."AO_CLRY_OLO" ("CLEAN_OLO_REF") 
  ;
