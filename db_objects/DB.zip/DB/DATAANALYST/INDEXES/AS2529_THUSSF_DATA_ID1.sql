--------------------------------------------------------
--  DDL for Index AS2529_THUSSF_DATA_ID1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AS2529_THUSSF_DATA_ID1" ON "DATAANALYST"."AS2529_THUSSF_DATA" ("ID") 
  ;
