--------------------------------------------------------
--  DDL for Index CLEAN_TNBS_NUMBER_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CLEAN_TNBS_NUMBER_I1" ON "DATAANALYST"."P33_SSBS_CUSNORN_DETAILS_CLEAN" ("CLEAN_TNBS_NUMBER") 
  ;
