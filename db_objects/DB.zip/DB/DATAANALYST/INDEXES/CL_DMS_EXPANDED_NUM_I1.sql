--------------------------------------------------------
--  DDL for Index CL_DMS_EXPANDED_NUM_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CL_DMS_EXPANDED_NUM_I1" ON "DATAANALYST"."CL_DMS_EXPANDED_NUM" ("TEL_NUM") 
  ;
