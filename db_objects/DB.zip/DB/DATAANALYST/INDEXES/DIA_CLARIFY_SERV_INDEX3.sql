--------------------------------------------------------
--  DDL for Index DIA_CLARIFY_SERV_INDEX3
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."DIA_CLARIFY_SERV_INDEX3" ON "DATAANALYST"."DIA_CLARIFY_SERV" ("MASTER_SERVICE_ID") 
  ;
