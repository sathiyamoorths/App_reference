--------------------------------------------------------
--  DDL for Index CLRY_SERVICES_I5
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CLRY_SERVICES_I5" ON "DATAANALYST"."CLRY_SERVICES" ("CONTRACTUAL_BUS_ORG_OBJID") 
  ;
