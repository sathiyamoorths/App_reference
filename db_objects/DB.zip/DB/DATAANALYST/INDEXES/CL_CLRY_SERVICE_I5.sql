--------------------------------------------------------
--  DDL for Index CL_CLRY_SERVICE_I5
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CL_CLRY_SERVICE_I5" ON "DATAANALYST"."CL_CLRY_SERVICE" ("CI_OBJID") 
  ;
