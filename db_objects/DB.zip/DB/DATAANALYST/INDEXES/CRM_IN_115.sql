--------------------------------------------------------
--  DDL for Index CRM_IN_115
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CRM_IN_115" ON "DATAANALYST"."OPTICAL_CRAMER_MASTER_SERVICES" ("TOP_CIRCUITNAME") 
  ;
