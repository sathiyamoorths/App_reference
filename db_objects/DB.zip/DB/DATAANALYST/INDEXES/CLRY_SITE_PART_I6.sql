--------------------------------------------------------
--  DDL for Index CLRY_SITE_PART_I6
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CLRY_SITE_PART_I6" ON "DATAANALYST"."CLRY_SITE_PART" ("SERVICE_ID") 
  ;
