--------------------------------------------------------
--  DDL for Index CRM_IN_101
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CRM_IN_101" ON "DATAANALYST"."OPTICAL_CRM_CIRCUIT_DETAILS" ("ACTUAL_CIRCUITID") 
  ;
