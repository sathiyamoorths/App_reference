--------------------------------------------------------
--  DDL for Index AMDOCS_ORDERING_CKT_ALL_I2
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AMDOCS_ORDERING_CKT_ALL_I2" ON "DATAANALYST"."AMDOCS_ORDERING_CIRCUITS_ALL" ("LINKID") 
  ;
