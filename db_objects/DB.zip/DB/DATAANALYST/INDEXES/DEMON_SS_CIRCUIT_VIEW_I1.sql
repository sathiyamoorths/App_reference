--------------------------------------------------------
--  DDL for Index DEMON_SS_CIRCUIT_VIEW_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."DEMON_SS_CIRCUIT_VIEW_I1" ON "DATAANALYST"."DEMON_SS_CIRCUIT_VIEW" ("PRT_SERVICEID") 
  ;
