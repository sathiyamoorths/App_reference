--------------------------------------------------------
--  DDL for Index CL_ASSOC_ORDERS_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CL_ASSOC_ORDERS_I1" ON "DATAANALYST"."CL_ASSOC_ORDERS" ("LINKID") 
  ;
