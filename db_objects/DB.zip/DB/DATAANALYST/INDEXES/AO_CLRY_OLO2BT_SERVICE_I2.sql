--------------------------------------------------------
--  DDL for Index AO_CLRY_OLO2BT_SERVICE_I2
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AO_CLRY_OLO2BT_SERVICE_I2" ON "DATAANALYST"."AO_CLRY_OLO2BT_SERVICE" ("BT_SERVICE_ID") 
  ;
