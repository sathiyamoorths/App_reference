--------------------------------------------------------
--  DDL for Index AKJ_PRT_U_SERVICEVIEW_INDEX2
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AKJ_PRT_U_SERVICEVIEW_INDEX2" ON "DATAANALYST"."AKJ_PRT_U_SERVICEVIEW" ("PROJECTID") 
  ;
