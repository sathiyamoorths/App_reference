--------------------------------------------------------
--  DDL for Index DIA_CLARIFY_CUST_INDEX2
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."DIA_CLARIFY_CUST_INDEX2" ON "DATAANALYST"."DIA_CLARIFY_CUST" ("DELIVERY_CUSTID") 
  ;
