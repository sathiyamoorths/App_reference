--------------------------------------------------------
--  DDL for Index AMDOCS_ORDERING_CKT_ALL_I4
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AMDOCS_ORDERING_CKT_ALL_I4" ON "DATAANALYST"."AMDOCS_ORDERING_CIRCUITS_ALL" ("HOW_FOUND") 
  ;
