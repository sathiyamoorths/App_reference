--------------------------------------------------------
--  DDL for Index AO_CLRY_ORDER2CIRCUIT_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AO_CLRY_ORDER2CIRCUIT_I1" ON "DATAANALYST"."AO_CLRY_ORDER2CIRCUIT" ("CIRCUIT_NAME") 
  ;
