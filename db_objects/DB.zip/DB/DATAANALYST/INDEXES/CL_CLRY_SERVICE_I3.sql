--------------------------------------------------------
--  DDL for Index CL_CLRY_SERVICE_I3
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CL_CLRY_SERVICE_I3" ON "DATAANALYST"."CL_CLRY_SERVICE" ("X_SITE_PART2BUS_ORG") 
  ;
