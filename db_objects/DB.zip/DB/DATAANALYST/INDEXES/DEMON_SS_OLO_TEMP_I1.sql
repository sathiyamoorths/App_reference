--------------------------------------------------------
--  DDL for Index DEMON_SS_OLO_TEMP_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."DEMON_SS_OLO_TEMP_I1" ON "DATAANALYST"."DEMON_SS_OLO_TEMP" ("SERVICE_ID") 
  ;
