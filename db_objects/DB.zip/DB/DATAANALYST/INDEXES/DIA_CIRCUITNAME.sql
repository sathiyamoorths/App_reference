--------------------------------------------------------
--  DDL for Index DIA_CIRCUITNAME
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."DIA_CIRCUITNAME" ON "DATAANALYST"."DIA_CRAMER_CKT_DETAIL" ("CIRCUITNAME") 
  ;
