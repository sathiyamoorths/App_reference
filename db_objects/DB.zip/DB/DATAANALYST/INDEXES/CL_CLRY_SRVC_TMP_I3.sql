--------------------------------------------------------
--  DDL for Index CL_CLRY_SRVC_TMP_I3
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CL_CLRY_SRVC_TMP_I3" ON "DATAANALYST"."CL_CLRY_SRVC_TMP" ("CI_OBJID") 
  ;
