--------------------------------------------------------
--  DDL for Index CLRY_CASES_I3
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CLRY_CASES_I3" ON "DATAANALYST"."CLRY_CASES" ("S_SERIAL_NO") 
  ;
