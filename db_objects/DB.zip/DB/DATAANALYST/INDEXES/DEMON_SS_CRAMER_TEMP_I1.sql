--------------------------------------------------------
--  DDL for Index DEMON_SS_CRAMER_TEMP_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."DEMON_SS_CRAMER_TEMP_I1" ON "DATAANALYST"."DEMON_SS_CRAMER_TEMP" ("SERVICE_ID") 
  ;
