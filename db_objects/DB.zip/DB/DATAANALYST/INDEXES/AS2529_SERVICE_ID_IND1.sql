--------------------------------------------------------
--  DDL for Index AS2529_SERVICE_ID_IND1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AS2529_SERVICE_ID_IND1" ON "DATAANALYST"."AS2529_SERVICE_ID" ("LINK_ID") 
  ;
