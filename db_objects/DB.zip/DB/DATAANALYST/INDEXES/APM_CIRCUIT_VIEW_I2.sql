--------------------------------------------------------
--  DDL for Index APM_CIRCUIT_VIEW_I2
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."APM_CIRCUIT_VIEW_I2" ON "DATAANALYST"."APM_CIRCUIT_VIEW" ("CIRCUIT_NAME") 
  ;
