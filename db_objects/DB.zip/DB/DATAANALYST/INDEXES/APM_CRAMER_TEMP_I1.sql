--------------------------------------------------------
--  DDL for Index APM_CRAMER_TEMP_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."APM_CRAMER_TEMP_I1" ON "DATAANALYST"."APM_CRAMER_TEMP" ("SERVICE_ID") 
  ;
