--------------------------------------------------------
--  DDL for Index CONTACT_LITE_NETWORK_VIEW_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CONTACT_LITE_NETWORK_VIEW_I1" ON "DATAANALYST"."CONTACT_LITE_NETWORK_VIEW" ("LINKID") 
  ;
