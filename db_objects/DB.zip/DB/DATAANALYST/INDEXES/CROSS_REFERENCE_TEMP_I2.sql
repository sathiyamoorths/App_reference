--------------------------------------------------------
--  DDL for Index CROSS_REFERENCE_TEMP_I2
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CROSS_REFERENCE_TEMP_I2" ON "DATAANALYST"."CROSS_REFERENCE_TEMP" ("EXT_MORI_REFERENCE") 
  ;
