--------------------------------------------------------
--  DDL for Index DEMON_SS_CIRCUIT_DETAILS_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."DEMON_SS_CIRCUIT_DETAILS_I1" ON "DATAANALYST"."DEMON_SS_CIRCUIT_DETAILS" ("SERVICE_ID") 
  ;
