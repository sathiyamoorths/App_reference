--------------------------------------------------------
--  DDL for Index CLRY_SITE_PART_I4
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CLRY_SITE_PART_I4" ON "DATAANALYST"."CLRY_SITE_PART" (TO_CHAR("SITE_PART_OBJID")) 
  ;
