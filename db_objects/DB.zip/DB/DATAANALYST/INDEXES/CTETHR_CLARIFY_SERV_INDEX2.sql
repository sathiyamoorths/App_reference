--------------------------------------------------------
--  DDL for Index CTETHR_CLARIFY_SERV_INDEX2
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CTETHR_CLARIFY_SERV_INDEX2" ON "DATAANALYST"."CITY_ETHERNET_CLARIFY_SERV" ("CLARIFY_CIRCUIT_TYPE") 
  ;
