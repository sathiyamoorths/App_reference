--------------------------------------------------------
--  DDL for Index CLRY_AO_CIRCUIT_I4
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CLRY_AO_CIRCUIT_I4" ON "DATAANALYST"."CLRY_AO_CIRCUIT_MAPPING" ("AO_SERVICE_ID") 
  ;
