--------------------------------------------------------
--  DDL for Index CRM_SERVICEVIEW_DRIV_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CRM_SERVICEVIEW_DRIV_I1" ON "DATAANALYST"."CRM_SERVICEVIEW_DRIV" ("SEARCHED_MAIN_ITEM_ID") 
  ;
