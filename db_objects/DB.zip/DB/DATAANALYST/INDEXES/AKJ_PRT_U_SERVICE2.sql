--------------------------------------------------------
--  DDL for Index AKJ_PRT_U_SERVICE2
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AKJ_PRT_U_SERVICE2" ON "DATAANALYST"."AKJ_PRT_U_SERVICEVIEW_TEMP" ("BILLING_SERVICE_REF") 
  ;
