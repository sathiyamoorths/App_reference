--------------------------------------------------------
--  DDL for Index CLRY_SITES_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CLRY_SITES_I1" ON "DATAANALYST"."CLRY_SITES" ("SERVICE_OBJID") 
  ;
