--------------------------------------------------------
--  DDL for Index CRM_TEMP_GEN_2_I
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CRM_TEMP_GEN_2_I" ON "DATAANALYST"."CRM_TEMP_GEN_2" ("PRT_SERVICE_ID") 
  ;
