--------------------------------------------------------
--  DDL for Index AKJ_WAN_OPTIMISATION_I3
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AKJ_WAN_OPTIMISATION_I3" ON "DATAANALYST"."AKJ_WAN_OPTIMISATION" ("CLI") 
  ;
