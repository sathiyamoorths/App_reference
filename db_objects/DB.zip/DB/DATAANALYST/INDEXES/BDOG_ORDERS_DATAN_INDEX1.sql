--------------------------------------------------------
--  DDL for Index BDOG_ORDERS_DATAN_INDEX1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."BDOG_ORDERS_DATAN_INDEX1" ON "DATAANALYST"."BDOG_ORDERS_DATA_NEW" ("DN_NUMBER") 
  ;
