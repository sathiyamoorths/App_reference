--------------------------------------------------------
--  DDL for Index AKJ_MPLS_INDEX3
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AKJ_MPLS_INDEX3" ON "DATAANALYST"."AKJ_MPLS" ("CLI") 
  ;
