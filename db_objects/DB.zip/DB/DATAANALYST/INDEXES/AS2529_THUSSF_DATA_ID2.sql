--------------------------------------------------------
--  DDL for Index AS2529_THUSSF_DATA_ID2
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AS2529_THUSSF_DATA_ID2" ON "DATAANALYST"."AS2529_THUSSF_DATA" ("CLEANED_CIRCUITREF") 
  ;
