--------------------------------------------------------
--  DDL for Index BILL_I3
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."BILL_I3" ON "DATAANALYST"."MAGUIRE_CRM6_BILLING_DETAIL_2" ("COMPANY_REG_NO") 
  ;
