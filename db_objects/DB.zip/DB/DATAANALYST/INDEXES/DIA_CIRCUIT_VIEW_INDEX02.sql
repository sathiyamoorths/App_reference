--------------------------------------------------------
--  DDL for Index DIA_CIRCUIT_VIEW_INDEX02
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."DIA_CIRCUIT_VIEW_INDEX02" ON "DATAANALYST"."DIA_CIRCUIT_VIEW" ("CIRCUIT_NAME") 
  ;
