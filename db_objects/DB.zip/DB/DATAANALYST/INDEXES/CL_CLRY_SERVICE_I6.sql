--------------------------------------------------------
--  DDL for Index CL_CLRY_SERVICE_I6
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CL_CLRY_SERVICE_I6" ON "DATAANALYST"."CL_CLRY_SERVICE" ("CONTRACTUAL_BUS_ORG_OBJID") 
  ;
