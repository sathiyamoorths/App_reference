--------------------------------------------------------
--  DDL for Index CLRY_SERVICES1_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CLRY_SERVICES1_I1" ON "DATAANALYST"."CLRY_SERVICES1" ("S_SERIAL_NO") 
  ;
