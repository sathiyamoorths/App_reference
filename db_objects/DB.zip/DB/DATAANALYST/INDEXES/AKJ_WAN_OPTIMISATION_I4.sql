--------------------------------------------------------
--  DDL for Index AKJ_WAN_OPTIMISATION_I4
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AKJ_WAN_OPTIMISATION_I4" ON "DATAANALYST"."AKJ_WAN_OPTIMISATION" ("SUPPLIER_PRODUCT_REF_CLEAN") 
  ;
