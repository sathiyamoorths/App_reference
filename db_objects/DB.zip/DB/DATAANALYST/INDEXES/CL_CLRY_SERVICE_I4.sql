--------------------------------------------------------
--  DDL for Index CL_CLRY_SERVICE_I4
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CL_CLRY_SERVICE_I4" ON "DATAANALYST"."CL_CLRY_SERVICE" ("CASE_OBJID") 
  ;
