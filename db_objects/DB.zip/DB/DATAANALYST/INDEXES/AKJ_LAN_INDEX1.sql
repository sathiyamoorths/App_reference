--------------------------------------------------------
--  DDL for Index AKJ_LAN_INDEX1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AKJ_LAN_INDEX1" ON "DATAANALYST"."AKJ_LAN" ("PRODUCTDESCRIPTION") 
  ;
