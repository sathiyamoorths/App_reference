--------------------------------------------------------
--  DDL for Index AS2529_SERVICE_VW_INDX
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AS2529_SERVICE_VW_INDX" ON "DATAANALYST"."AS2529_SERVICE_VIEW" ("SERVICE_ID") 
  ;
