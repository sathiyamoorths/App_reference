--------------------------------------------------------
--  DDL for Index AKJ_LAN_INDEX3
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AKJ_LAN_INDEX3" ON "DATAANALYST"."AKJ_LAN" ("CLI") 
  ;
