--------------------------------------------------------
--  DDL for Index AKJ_MYINBOUND_PRODUCT_TMP_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AKJ_MYINBOUND_PRODUCT_TMP_I1" ON "DATAANALYST"."AKJ_MYINBOUND_PRODUCT_TMP" ("CLEAN_CLI") 
  ;
