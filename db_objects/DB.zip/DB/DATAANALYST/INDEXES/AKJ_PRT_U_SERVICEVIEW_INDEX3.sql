--------------------------------------------------------
--  DDL for Index AKJ_PRT_U_SERVICEVIEW_INDEX3
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AKJ_PRT_U_SERVICEVIEW_INDEX3" ON "DATAANALYST"."AKJ_PRT_U_SERVICEVIEW" ("BILLING_ACC_NO") 
  ;
