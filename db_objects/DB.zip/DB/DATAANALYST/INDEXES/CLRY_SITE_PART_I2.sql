--------------------------------------------------------
--  DDL for Index CLRY_SITE_PART_I2
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CLRY_SITE_PART_I2" ON "DATAANALYST"."CLRY_SITE_PART" ("S_SERIAL_NO") 
  ;
