--------------------------------------------------------
--  DDL for Index DEVICE_CIRCUIT_COUNT_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."DEVICE_CIRCUIT_COUNT_I1" ON "DATAANALYST"."DEVICE_CIRCUIT_COUNT" ("DEVICE") 
  ;
