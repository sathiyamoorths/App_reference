--------------------------------------------------------
--  DDL for Index CITY_ETHERNET_UNO_DATA_INDEX1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CITY_ETHERNET_UNO_DATA_INDEX1" ON "DATAANALYST"."CITY_ETHERNET_UNO_DATA" ("PARENTNO") 
  ;
