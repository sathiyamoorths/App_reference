--------------------------------------------------------
--  DDL for Index AKJ_NPARTY_MAPPING_INDEX1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AKJ_NPARTY_MAPPING_INDEX1" ON "DATAANALYST"."AKJ_NOMINATED_PARTY_MAPPING" ("AKJ_CUSTOMER_NAME") 
  ;
