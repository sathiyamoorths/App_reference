--------------------------------------------------------
--  DDL for Index CL_BILLING_DETAIL_TEMP_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CL_BILLING_DETAIL_TEMP_I1" ON "DATAANALYST"."CL_BILLING_DETAIL_TEMP" ("SERVICE_ID") 
  ;
