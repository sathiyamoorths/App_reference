--------------------------------------------------------
--  DDL for Index BILL_TOTAL_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."BILL_TOTAL_I1" ON "DATAANALYST"."MAGUIRE_CRM6_BILLING_TOTAL" ("SERVICE_ID") 
  ;
