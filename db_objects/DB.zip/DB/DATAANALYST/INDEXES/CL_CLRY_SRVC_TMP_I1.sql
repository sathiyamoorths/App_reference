--------------------------------------------------------
--  DDL for Index CL_CLRY_SRVC_TMP_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CL_CLRY_SRVC_TMP_I1" ON "DATAANALYST"."CL_CLRY_SRVC_TMP" ("SERVICE_OBJID") 
  ;
