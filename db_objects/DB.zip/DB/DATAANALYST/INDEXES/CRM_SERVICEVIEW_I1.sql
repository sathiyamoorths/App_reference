--------------------------------------------------------
--  DDL for Index CRM_SERVICEVIEW_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CRM_SERVICEVIEW_I1" ON "DATAANALYST"."CRM_SERVICEVIEW" ("MAIN_ID") 
  ;
