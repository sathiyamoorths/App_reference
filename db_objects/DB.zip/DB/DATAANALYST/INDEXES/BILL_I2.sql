--------------------------------------------------------
--  DDL for Index BILL_I2
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."BILL_I2" ON "DATAANALYST"."MAGUIRE_CRM6_BILLING_DETAIL_2" ("BILLING_ACCOUNT_NO") 
  ;
