--------------------------------------------------------
--  DDL for Index CLRY_SERVICES_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CLRY_SERVICES_I1" ON "DATAANALYST"."CLRY_SERVICES" ("SERVICE_OBJID") 
  ;
