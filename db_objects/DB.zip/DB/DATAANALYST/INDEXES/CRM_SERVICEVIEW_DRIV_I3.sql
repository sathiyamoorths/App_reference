--------------------------------------------------------
--  DDL for Index CRM_SERVICEVIEW_DRIV_I3
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CRM_SERVICEVIEW_DRIV_I3" ON "DATAANALYST"."CRM_SERVICEVIEW_DRIV" ("CRM_SERVICE_ID") 
  ;
