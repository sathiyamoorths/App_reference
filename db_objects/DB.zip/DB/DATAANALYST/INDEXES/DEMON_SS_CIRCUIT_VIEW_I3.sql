--------------------------------------------------------
--  DDL for Index DEMON_SS_CIRCUIT_VIEW_I3
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."DEMON_SS_CIRCUIT_VIEW_I3" ON "DATAANALYST"."DEMON_SS_CIRCUIT_VIEW" ("LINKID") 
  ;
