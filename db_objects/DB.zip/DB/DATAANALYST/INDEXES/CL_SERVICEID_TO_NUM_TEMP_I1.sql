--------------------------------------------------------
--  DDL for Index CL_SERVICEID_TO_NUM_TEMP_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CL_SERVICEID_TO_NUM_TEMP_I1" ON "DATAANALYST"."CL_SERVICEID_TO_NUM_TEMP" ("SERVICE_ID") 
  ;
