--------------------------------------------------------
--  DDL for Index AMDOCS_ORDER_DETAILS_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AMDOCS_ORDER_DETAILS_I1" ON "DATAANALYST"."AMDOCS_ORDER_DETAILS" ("LINKID") 
  ;
