--------------------------------------------------------
--  DDL for Index CLRY_AO_SERVICE_I3
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CLRY_AO_SERVICE_I3" ON "DATAANALYST"."CLRY_AO_SERVICE_MAPPING" ("AO_SERVICE_ID") 
  ;
