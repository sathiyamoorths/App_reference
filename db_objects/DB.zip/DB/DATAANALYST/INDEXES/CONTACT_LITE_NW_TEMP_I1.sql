--------------------------------------------------------
--  DDL for Index CONTACT_LITE_NW_TEMP_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CONTACT_LITE_NW_TEMP_I1" ON "DATAANALYST"."CONTACT_LITE_NW_TEMP" ("PRT_SERVICEID") 
  ;
