--------------------------------------------------------
--  DDL for Index CLEAN_BILLING_ACCOUNT_NO_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CLEAN_BILLING_ACCOUNT_NO_I1" ON "DATAANALYST"."CLEAN_BILLING_ACCOUNT_NO" ("SERVICE_ID") 
  ;
