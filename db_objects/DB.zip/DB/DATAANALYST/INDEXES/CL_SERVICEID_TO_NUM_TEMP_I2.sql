--------------------------------------------------------
--  DDL for Index CL_SERVICEID_TO_NUM_TEMP_I2
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CL_SERVICEID_TO_NUM_TEMP_I2" ON "DATAANALYST"."CL_SERVICEID_TO_NUM_TEMP" ("DIALEDNUMBERSTRING") 
  ;
