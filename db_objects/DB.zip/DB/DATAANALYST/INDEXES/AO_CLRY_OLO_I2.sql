--------------------------------------------------------
--  DDL for Index AO_CLRY_OLO_I2
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AO_CLRY_OLO_I2" ON "DATAANALYST"."AO_CLRY_OLO" ("SERVICE_ID") 
  ;
