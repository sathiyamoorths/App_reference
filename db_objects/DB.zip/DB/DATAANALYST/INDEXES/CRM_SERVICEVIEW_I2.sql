--------------------------------------------------------
--  DDL for Index CRM_SERVICEVIEW_I2
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CRM_SERVICEVIEW_I2" ON "DATAANALYST"."CRM_SERVICEVIEW" ("PRT_SERVICE_ID") 
  ;
