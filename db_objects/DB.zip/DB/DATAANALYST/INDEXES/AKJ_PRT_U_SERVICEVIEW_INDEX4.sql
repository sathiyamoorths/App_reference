--------------------------------------------------------
--  DDL for Index AKJ_PRT_U_SERVICEVIEW_INDEX4
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AKJ_PRT_U_SERVICEVIEW_INDEX4" ON "DATAANALYST"."AKJ_PRT_U_SERVICEVIEW" ("BILLING_SERVICE_REF") 
  ;
