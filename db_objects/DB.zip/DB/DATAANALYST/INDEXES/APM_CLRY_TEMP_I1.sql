--------------------------------------------------------
--  DDL for Index APM_CLRY_TEMP_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."APM_CLRY_TEMP_I1" ON "DATAANALYST"."APM_CLRY_TEMP" ("SERVICE_ID") 
  ;
