--------------------------------------------------------
--  DDL for Index CLRY_SERVICES_I7
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CLRY_SERVICES_I7" ON "DATAANALYST"."CLRY_SERVICES" ("B_END_SITE_OBJID") 
  ;
