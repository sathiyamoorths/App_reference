--------------------------------------------------------
--  DDL for Index AMDOCS_ORDERING_CIRCUITS_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AMDOCS_ORDERING_CIRCUITS_I1" ON "DATAANALYST"."AMDOCS_ORDERING_CIRCUITS" ("SERVICE_ID") 
  ;
