--------------------------------------------------------
--  DDL for Index CLRY_SITE_PART_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CLRY_SITE_PART_I1" ON "DATAANALYST"."CLRY_SITE_PART" ("SERVICE_OBJID") 
  ;
