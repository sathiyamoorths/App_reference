--------------------------------------------------------
--  DDL for Index AKJ_MPLS_INDEX1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AKJ_MPLS_INDEX1" ON "DATAANALYST"."AKJ_MPLS" ("PRODUCTDESCRIPTION") 
  ;
