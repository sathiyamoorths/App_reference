--------------------------------------------------------
--  DDL for Index CLEAN_INVENTORY_CIRCUIT_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CLEAN_INVENTORY_CIRCUIT_I1" ON "DATAANALYST"."CLEAN_INVENTORY_CIRCUIT_REFS" ("SERVICE_ID") 
  ;
