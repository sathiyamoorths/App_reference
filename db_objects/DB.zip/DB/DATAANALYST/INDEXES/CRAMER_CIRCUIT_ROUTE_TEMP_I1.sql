--------------------------------------------------------
--  DDL for Index CRAMER_CIRCUIT_ROUTE_TEMP_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CRAMER_CIRCUIT_ROUTE_TEMP_I1" ON "DATAANALYST"."CRAMER_CIRCUIT_ROUTE_TEMP" ("START_CCTID") 
  ;
