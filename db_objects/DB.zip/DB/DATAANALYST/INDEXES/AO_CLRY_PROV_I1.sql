--------------------------------------------------------
--  DDL for Index AO_CLRY_PROV_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AO_CLRY_PROV_I1" ON "DATAANALYST"."MAGUIRE_AO_CL_PROV_DETAILS" ("SERVICE_ID") 
  ;
