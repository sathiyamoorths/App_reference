--------------------------------------------------------
--  DDL for Index CLRY_SERVICES_I3
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CLRY_SERVICES_I3" ON "DATAANALYST"."CLRY_SERVICES" ("CASE_OBJID") 
  ;
