--------------------------------------------------------
--  DDL for Index CLEAN_ORDER_NUMBER_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CLEAN_ORDER_NUMBER_I1" ON "DATAANALYST"."CLEAN_ORDER_NUMBER" ("SERVICE_ID") 
  ;
