--------------------------------------------------------
--  DDL for Index CLRY_SITE_PART_I7
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CLRY_SITE_PART_I7" ON "DATAANALYST"."CLRY_SITE_PART" ("X_TYPE") 
  ;
