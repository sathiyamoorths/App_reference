--------------------------------------------------------
--  DDL for Index CLRY_SERVICES_I4
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CLRY_SERVICES_I4" ON "DATAANALYST"."CLRY_SERVICES" ("PID") 
  ;
