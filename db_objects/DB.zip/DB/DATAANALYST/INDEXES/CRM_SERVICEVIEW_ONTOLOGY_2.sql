--------------------------------------------------------
--  DDL for Index CRM_SERVICEVIEW_ONTOLOGY_2
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CRM_SERVICEVIEW_ONTOLOGY_2" ON "DATAANALYST"."CRM_SERVICEVIEW_ONTOLOGY" ("CLARIFY_OBJID") 
  ;
