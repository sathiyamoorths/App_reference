--------------------------------------------------------
--  DDL for Index AKJ_PRT_U_SERVICEVIEW_INDEX6
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AKJ_PRT_U_SERVICEVIEW_INDEX6" ON "DATAANALYST"."AKJ_PRT_U_SERVICEVIEW" ("SERVICE_ID") 
  ;
