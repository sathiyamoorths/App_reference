--------------------------------------------------------
--  DDL for Index BILLING_DETAILS_TEMP_T1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."BILLING_DETAILS_TEMP_T1" ON "DATAANALYST"."BILLING_DETAILS_TEMP" ("ACCOUNT_NO") 
  ;
