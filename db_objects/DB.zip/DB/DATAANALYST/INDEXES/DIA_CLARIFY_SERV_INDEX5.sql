--------------------------------------------------------
--  DDL for Index DIA_CLARIFY_SERV_INDEX5
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."DIA_CLARIFY_SERV_INDEX5" ON "DATAANALYST"."DIA_CLARIFY_SERV" ("CLEAN_SERVICE_NAME") 
  ;
