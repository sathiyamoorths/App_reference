--------------------------------------------------------
--  DDL for Index AKJ_GAMMA_SIP_ALL_INDEX4
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AKJ_GAMMA_SIP_ALL_INDEX4" ON "DATAANALYST"."AKJ_GAMMA_SIP_ALL" ("END_POINT_4") 
  ;
