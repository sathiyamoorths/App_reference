--------------------------------------------------------
--  DDL for Index AKJ_PRT_U_CONTRACT_INDEX1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AKJ_PRT_U_CONTRACT_INDEX1" ON "DATAANALYST"."AKJ_PRT_U_CONTRACTITEMS2" ("PRT_SERVICEID") 
  ;
