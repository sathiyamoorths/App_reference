--------------------------------------------------------
--  DDL for Index CTETHR_ENERGIS_CLRFY_SERV_INDX
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CTETHR_ENERGIS_CLRFY_SERV_INDX" ON "DATAANALYST"."CITY_ETHERNET_CLARIFY_SERV" ("CLARIFY_SERVICE_OBJID") 
  ;
