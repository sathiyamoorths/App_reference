--------------------------------------------------------
--  DDL for Index AKJ_LAN_INDEX2
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."AKJ_LAN_INDEX2" ON "DATAANALYST"."AKJ_LAN" ("SUPPLIER_PRODUCT_REFERENCE") 
  ;
