--------------------------------------------------------
--  DDL for Index CRM_IN_113
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CRM_IN_113" ON "DATAANALYST"."OPTICAL_CRM_TOP_CIRCUITS" ("ACTUAL_TOP_CIRCUITNAME") 
  ;
