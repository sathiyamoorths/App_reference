--------------------------------------------------------
--  DDL for Index CLRY_AO_CIRCUIT_I1
--------------------------------------------------------

  CREATE INDEX "DATAANALYST"."CLRY_AO_CIRCUIT_I1" ON "DATAANALYST"."CLRY_AO_CIRCUIT_MAPPING" ("CLRY_SERVICE_OBJID") 
  ;
