--------------------------------------------------------
--  DDL for Function F_REMOVE_CARRIAGE_RETURN
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "DATAANALYST"."F_REMOVE_CARRIAGE_RETURN" (V VARCHAR2, R VARCHAR2)
    RETURN VARCHAR2 IS

    RETVAL VARCHAR2(4000);
    
    -- V IS THE STRING THAT NEEDS CLEANSING
    -- R IS THE REPLACEMENT CHAR
    
    
BEGIN
    
   RETVAL := TRIM(TRIM ( BOTH R FROM TRIM(TRIM ( BOTH R FROM TRIM(REPLACE(TRIM(V),CHR(13) || CHR(10),R))))))
   ;
    
   RETURN RETVAL;

END;

/
