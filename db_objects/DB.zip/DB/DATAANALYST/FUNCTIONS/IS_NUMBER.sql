--------------------------------------------------------
--  DDL for Function IS_NUMBER
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "DATAANALYST"."IS_NUMBER" (P_STRING IN VARCHAR2)
   RETURN INT
IS
   V_NEW_NUM NUMBER;
BEGIN
   V_NEW_NUM := TO_NUMBER(P_STRING);
   RETURN 1;
EXCEPTION
WHEN VALUE_ERROR THEN
   RETURN 0;
END IS_NUMBER;

/
