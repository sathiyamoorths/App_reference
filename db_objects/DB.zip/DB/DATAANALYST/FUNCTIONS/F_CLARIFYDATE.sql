--------------------------------------------------------
--  DDL for Function F_CLARIFYDATE
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "DATAANALYST"."F_CLARIFYDATE" ( inputdate date)
RETURN date IS
tmpVar date;
/******************************************************************************
   NAME:       f_clarifydate
   PURPOSE:    

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        29/10/2015   w425161       1. Created this function.

   NOTES:

   Automatically available Auto Replace Keywords:
      Object Name:     f_clarifydate
      Sysdate:         29/10/2015
      Date and Time:   29/10/2015, 16:08:20, and 29/10/2015 16:08:20
      Username:        w425161 (set in TOAD Options, Procedure Editor)
      Table Name:       (set in the "New PL/SQL Object" dialog)

******************************************************************************/
BEGIN
   
   
   if inputdate = to_date('01/01/1753','dd/mm/yyyy') then
        tmpVar := null;
   else     
       tmpVar := inputdate;
   end if;
   
     
   RETURN tmpVar;
   EXCEPTION
     WHEN NO_DATA_FOUND THEN
       NULL;
     WHEN OTHERS THEN
       -- Consider logging the error and then re-raise
       RAISE;
END f_clarifydate;

/
