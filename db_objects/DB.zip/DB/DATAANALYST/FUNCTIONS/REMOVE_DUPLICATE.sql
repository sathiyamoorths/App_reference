--------------------------------------------------------
--  DDL for Function REMOVE_DUPLICATE
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "DATAANALYST"."REMOVE_DUPLICATE" (
    val IN VARCHAR2)
  RETURN VARCHAR2
IS
  RETVAL VARCHAR2(4000);
BEGIN
  --with cte (t,dt) as (
  --   select distinct 1 as t,str as dt from
  --(select regexp_substr (V, '[^; ]+',1, rownum) str
  --from dual
  --connect by level <= regexp_count (V, '[^; ]+'))
  --)
  --Select distinct  listagg(dt,';')
  --within group ( Order by t)
  --   as servicename into RETVAL
  --from cte
  --group by  t;
WITH test (id, col) AS
  (SELECT 1,val FROM dual
  ),
  t_rows AS
  (SELECT id,
    trim(regexp_substr(col, '[^,]+', 1, column_value)) col,
    column_value rn
  FROM test,
    TABLE(CAST(multiset
    (SELECT level FROM dual CONNECT BY level <= regexp_count(col, ',') + 1
    ) AS sys.odcinumberlist))
  ),
  t_distinct AS
  (SELECT id, col, MIN(rn) min_rn FROM t_rows GROUP BY id, col
  )
SELECT listagg(col, ', ') within GROUP (
ORDER BY min_rn) AS result
INTO RETVAL
FROM t_distinct
GROUP BY id;
RETURN RETVAL;
END;

/
