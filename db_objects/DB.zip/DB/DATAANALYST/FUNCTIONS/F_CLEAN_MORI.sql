--------------------------------------------------------
--  DDL for Function F_CLEAN_MORI
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "DATAANALYST"."F_CLEAN_MORI" (V VARCHAR2)
    RETURN VARCHAR2 IS

    RETVAL VARCHAR2(100);
    X      VARCHAR2(100);
    Z      VARCHAR2(100);
    
BEGIN
    
    Z  := trim(UPPER(V));
    X  := TM_TRANSLATE(Z,3);
    
    IF    X = 'Z0000000Z' THEN RETVAL := Z;
    ELSIF X = 'Z000000Z'  THEN RETVAL := SUBSTR(Z,1,1) || '0'    || SUBSTR(Z,2,10) ;
    ELSIF X = 'Z00000Z'   THEN RETVAL := SUBSTR(Z,1,1) || '00'   || SUBSTR(Z,2,10) ;
    ELSIF X = 'Z0000Z'    THEN RETVAL := SUBSTR(Z,1,1) || '000'  || SUBSTR(Z,2,10) ;
    ELSIF X = 'Z000Z'     THEN RETVAL := SUBSTR(Z,1,1) || '0000' || SUBSTR(Z,2,10);
    ELSIF X = 'Z0000000'  THEN RETVAL := Z || 'A';
    ELSIF X = 'Z000000'   THEN RETVAL := SUBSTR(Z,1,1) || '0'    || SUBSTR(Z,2,10) || 'A';
    ELSIF X = 'Z00000'    THEN RETVAL := SUBSTR(Z,1,1) || '00'   || SUBSTR(Z,2,10) || 'A';
    ELSIF X = 'Z0000'     THEN RETVAL := SUBSTR(Z,1,1) || '000'  || SUBSTR(Z,2,10) || 'A';
    ELSIF X = 'Z000'      THEN RETVAL := SUBSTR(Z,1,1) || '0000' || SUBSTR(Z,2,10) || 'A'; 
    ELSIF X = 'Z 0000000Z'  THEN RETVAL := REPLACE(Z,' ','');
    ELSIF X = 'Z 000000Z'  THEN RETVAL := REPLACE(Z,' ','0');
    ELSIF X = 'Z 00000Z'  THEN RETVAL := REPLACE(Z,' ','00');
    ELSIF X = 'Z 0000Z'  THEN RETVAL := REPLACE(Z,' ','000');
    ELSE  RETVAL := V;
    END IF;
    
    RETURN RETVAL;

END;

/
