--------------------------------------------------------
--  DDL for Function CLEAN_AKJ_CLI
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "DATAANALYST"."CLEAN_AKJ_CLI" (CLI_DIRTY VARCHAR2)

RETURN VARCHAR2 IS

RETVAL VARCHAR2 (4000);

--PROVIDE CLEAN CLI

BEGIN

RETVAL := CLI_DIRTY;

RETVAL := replace(RETVAL,'ADSL','');

RETVAL := replace(RETVAL,'adsl','');

IF REGEXP_LIKE (RETVAL,'[0-9]R$') THEN RETVAL := REPLACE(RETVAL,'R','');
END IF;

IF REGEXP_LIKE (RETVAL,'[0-9]r$') THEN RETVAL := REPLACE(RETVAL,'r','');
END IF;

IF REGEXP_LIKE (RETVAL,'[0-9]A$') THEN RETVAL := REPLACE(RETVAL,'A','');
END IF;

IF REGEXP_LIKE (RETVAL,'[0-9]a$') THEN RETVAL := REPLACE(RETVAL,'a','');
END IF;

IF REGEXP_LIKE (RETVAL, '[0-9]{10,11}\s(GAMMA)') THEN RETVAL := REPLACE(RETVAL,'GAMMA','');
END IF;

IF REGEXP_LIKE (RETVAL, '[0-9]{10,11}\s(gamma)') THEN RETVAL := REPLACE(RETVAL,'gamma','');
END IF;

RETVAL := TRIM(RETVAL);

return RETVAL;

END;

/
