--------------------------------------------------------
--  DDL for Function F_REVERSE_STRING
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "DATAANALYST"."F_REVERSE_STRING" (VAL IN VARCHAR2) 

RETURN VARCHAR2 AS 
        RETVAL VARCHAR2(4000);
BEGIN

        SELECT  LISTAGG(TEXT, '|') WITHIN GROUP ( ORDER BY RN DESC ) REVERSED_INDICES INTO RETVAL
        FROM
        (
            SELECT  
                ROWNUM RN, TRIM(REGEXP_SUBSTR(T.TEXT, '[^|]+', 1, LINES.COLUMN_VALUE)) TEXT
            FROM
                (
                    SELECT VAL  TEXT FROM DUAL
                ) T,
                TABLE (CAST (MULTISET
                    (SELECT LEVEL FROM DUAL CONNECT BY LEVEL <= REGEXP_COUNT(T.TEXT, '|')+1 ) AS SYS.ODCINUMBERLIST ) ) LINES
         );
        RETURN RETVAL;
        
END F_REVERSE_STRING;

/
