--------------------------------------------------------
--  DDL for Function F_CLEAN_C00X
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "DATAANALYST"."F_CLEAN_C00X" (VV VARCHAR2)
    RETURN VARCHAR2 IS

    RETVAL VARCHAR2(100);
    X      VARCHAR2(20);
    V      VARCHAR2(20);
    
BEGIN
    V  := TRANSLATE(VV,'.-\_:','/////');
    V  := REPLACE(V,'//','/');
    X  := TRANSLATE(V,'123456789ABC.-\_','000000000ZZZ////');
    
    
    IF    X IN ('Z000/000000','Z000/Z00000') THEN  RETVAL := V;
    ELSIF X in ('Z000 / 000000','Z000/ 000000') THEN RETVAL := REPLACE(X,' ','');   
    ELSIF X = '000000'    THEN RETVAL := 'C002/' || V;
    ELSIF X = 'Z00000'    THEN RETVAL := 'C002/' || V;
    ELSIF X = 'Z0/000000' THEN RETVAL := 'C00' || SUBSTR(V,2,10);
    ELSIF X = 'Z0/Z00000' THEN RETVAL := 'C00' || SUBSTR(V,2,10);
    ELSIF X = 'Z/000000'  THEN RETVAL := 'C002' || SUBSTR(V,2,10);
    ELSIF X = 'Z/Z00000'  THEN RETVAL := 'C002' || SUBSTR(V,2,10);
    ELSIF X = 'Z0 / 000000' THEN RETVAL := 'C00' || SUBSTR(V,2,1) || '/' || SUBSTR(V,6,10);
    ELSIF X = 'Z0 / Z00000' THEN RETVAL := 'C00' || SUBSTR(V,2,1) || '/' || SUBSTR(V,6,10);
    ELSIF X = 'Z0 000000'  THEN RETVAL := 'C00' || SUBSTR(V,2,1) || '/' || SUBSTR(V,4,10);
    ELSIF X = 'Z0 Z00000'  THEN RETVAL := 'C00' || SUBSTR(V,2,1) || '/' || SUBSTR(V,4,10);
    ELSIF X = 'Z0/ 000000'  THEN RETVAL := 'C00' || SUBSTR(V,2,1) || '/' || SUBSTR(V,5,10);
    ELSIF X = 'Z0/ Z00000'  THEN RETVAL := 'C00' || SUBSTR(V,2,1) || '/' || SUBSTR(V,5,10);        
    ELSIF X = 'Z0 /000000'  THEN RETVAL := 'C00' || SUBSTR(V,2,1) || '/' || SUBSTR(V,5,10);
    ELSIF X = 'Z0 /Z00000'  THEN RETVAL := 'C00' || SUBSTR(V,2,1) || '/' || SUBSTR(V,5,10); 
    ELSIF X = 'Z0/Z0/000000' THEN RETVAL := 'C00' || SUBSTR(V,5,10);
    ELSIF X = 'Z0/Z0/Z00000' THEN RETVAL := 'C00' || SUBSTR(V,5,10);    
    ELSIF X = 'Z00/000000'   THEN RETVAL := 'C0' || SUBSTR(V,2,10);
    ELSIF X = 'Z000 000000'  THEN RETVAL := REPLACE(V,' ','/');
    ELSIF X = 'Z000 Z00000'  THEN RETVAL := REPLACE(V,' ','/');
    ELSIF X = 'Z000/000000/' THEN RETVAL := SUBSTR(V,1,11);
    ELSIF X = 'Z00/Z00000'   THEN RETVAL := 'C0' || SUBSTR(V,2,10);
    ELSIF X = 'Z00/00000'    THEN RETVAL := 'C0' || SUBSTR(V,2,10);
    ELSIF X = 'Z0Z00000'     THEN RETVAL := 'C00' || SUBSTR(V,2,1) || '/'  || SUBSTR(V,3,10);

    ELSE  RETVAL := V;
    END IF;
    
    RETURN RETVAL;

END;

/
