--------------------------------------------------------
--  DDL for DB Link IF_SCHEMA
--------------------------------------------------------

  CREATE DATABASE LINK "IF_SCHEMA"
   CONNECT TO "INSIGHTFACTORY" IDENTIFIED BY VALUES ':1'
   USING 'ONTYD1-DB.hosts.plc.cwintra.com:1521/ONTYD1';
