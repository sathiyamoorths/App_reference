--------------------------------------------------------
--  DDL for DB Link TEMP_DA_ONTYD2
--------------------------------------------------------

  CREATE DATABASE LINK "TEMP_DA_ONTYD2"
   CONNECT TO "DATAANALYST" IDENTIFIED BY VALUES ':1'
   USING 'ONTYD2';
