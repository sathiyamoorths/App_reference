--------------------------------------------------------
--  DDL for DB Link DATODEV
--------------------------------------------------------

  CREATE DATABASE LINK "DATODEV"
   CONNECT TO "DEVELOPMENT" IDENTIFIED BY VALUES ':1'
   USING 'KONAP1-DB.ad.plc.cwintra.com:1521/KONAP1';
