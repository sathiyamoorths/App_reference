--------------------------------------------------------
--  DDL for DB Link DATOPRUSER
--------------------------------------------------------

  CREATE DATABASE LINK "DATOPRUSER"
   CONNECT TO "PR_USER" IDENTIFIED BY VALUES ':1'
   USING 'KONAP1-DB.ad.plc.cwintra.com:1521/KONAP1';
