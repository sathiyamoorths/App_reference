--------------------------------------------------------
--  DDL for DB Link PRUSER_ONTYT1
--------------------------------------------------------

  CREATE DATABASE LINK "PRUSER_ONTYT1"
   CONNECT TO "PR_USER" IDENTIFIED BY VALUES ':1'
   USING 'ONTYT1-DB.hosts.plc.cwintra.com:1521/ONTYT1';
