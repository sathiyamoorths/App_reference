--------------------------------------------------------
--  DDL for DB Link DA_BIODP1
--------------------------------------------------------

  CREATE DATABASE LINK "DA_BIODP1"
   CONNECT TO "PR_USER" IDENTIFIED BY VALUES ':1'
   USING '(DESCRIPTION = 
    (ADDRESS_LIST = 
      (ADDRESS = (HOST = swixd01db-scan.ad.plc.cwintra.com)(PROTOCOL = TCP)(PORT = 1521)) 
      (ADDRESS = (HOST = exoxd01db-scan.ad.plc.cwintra.com)(PROTOCOL = TCP)(PORT = 1521)) 
   ) 
    (CONNECT_DATA = (SERVICE_NAME = BIODP1_RO)) 
  )';
