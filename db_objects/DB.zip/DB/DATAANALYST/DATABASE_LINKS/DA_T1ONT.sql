--------------------------------------------------------
--  DDL for DB Link DA_T1ONT
--------------------------------------------------------

  CREATE DATABASE LINK "DA_T1ONT"
   CONNECT TO "ONTOLOGY" IDENTIFIED BY VALUES ':1'
   USING 'ONTYT1-DB.hosts.plc.cwintra.com:1521/ONTYT1';
