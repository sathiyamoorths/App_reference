--------------------------------------------------------
--  DDL for DB Link PR_USER_ONTYD1
--------------------------------------------------------

  CREATE DATABASE LINK "PR_USER_ONTYD1"
   CONNECT TO "PR_USER" IDENTIFIED BY VALUES ':1'
   USING 'ONTYD1-DB.hosts.plc.cwintra.com:1521/ONTYD1';
