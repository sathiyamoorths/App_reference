--------------------------------------------------------
--  DDL for DB Link DATOONT
--------------------------------------------------------

  CREATE DATABASE LINK "DATOONT"
   CONNECT TO "ONTOLOGY" IDENTIFIED BY VALUES ':1'
   USING 'KONAP1-DB.ad.plc.cwintra.com:1521/KONAP1';
