--------------------------------------------------------
--  DDL for DB Link DA_ONTYD2
--------------------------------------------------------

  CREATE DATABASE LINK "DA_ONTYD2"
   CONNECT TO "DATAANALYST" IDENTIFIED BY VALUES ':1'
   USING 'ONTYD2';
