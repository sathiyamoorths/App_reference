--------------------------------------------------------
--  DDL for DB Link DA_ONTYT1
--------------------------------------------------------

  CREATE DATABASE LINK "DA_ONTYT1"
   CONNECT TO "DATAANALYST" IDENTIFIED BY VALUES ':1'
   USING 'ONTYT1-DB.hosts.plc.cwintra.com:1521/ONTYT1';
