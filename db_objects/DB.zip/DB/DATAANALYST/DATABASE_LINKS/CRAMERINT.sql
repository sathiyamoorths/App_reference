--------------------------------------------------------
--  DDL for DB Link CRAMERINT
--------------------------------------------------------

  CREATE DATABASE LINK "CRAMERINT"
   CONNECT TO "CRAMER" IDENTIFIED BY VALUES ':1'
   USING '(DESCRIPTION = (ADDRESS_LIST = (ADDRESS = (COMMUNITY = tcp)(PROTOCOL = TCP)
   (Host = cramer-db-dev-01.ad.plc.cwintra.com)(Port = 1521)))(CONNECT_DATA = (SID = c8int1)))';
