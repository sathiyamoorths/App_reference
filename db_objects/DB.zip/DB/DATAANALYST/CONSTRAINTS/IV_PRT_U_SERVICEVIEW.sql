--------------------------------------------------------
--  Constraints for Table IV_PRT_U_SERVICEVIEW
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."IV_PRT_U_SERVICEVIEW" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
