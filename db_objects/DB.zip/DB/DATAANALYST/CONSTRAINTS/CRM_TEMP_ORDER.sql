--------------------------------------------------------
--  Constraints for Table CRM_TEMP_ORDER
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."CRM_TEMP_ORDER" MODIFY ("PRT_SERVICE_ID" NOT NULL ENABLE);
