--------------------------------------------------------
--  Constraints for Table NW_NODE_TEMP
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."NW_NODE_TEMP" MODIFY ("NODEID" NOT NULL ENABLE);
