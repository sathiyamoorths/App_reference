--------------------------------------------------------
--  Constraints for Table PRTO_T_ADDRESS
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRTO_T_ADDRESS" MODIFY ("SITE_OBJID" NOT NULL ENABLE);
