--------------------------------------------------------
--  Constraints for Table TM_UCI_CCT_LIST
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."TM_UCI_CCT_LIST" MODIFY ("S_CIRCUITNAME" NOT NULL ENABLE);
