--------------------------------------------------------
--  Constraints for Table MAGUIRE_CRM6_BILLING_DETAILS
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."MAGUIRE_CRM6_BILLING_DETAILS" MODIFY ("BILLING_ACCOUNT_NO" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."MAGUIRE_CRM6_BILLING_DETAILS" MODIFY ("SOURCE_SYSTEM" NOT NULL ENABLE);
