--------------------------------------------------------
--  Constraints for Table PRT_T_CLRY_TX_REF1
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRT_T_CLRY_TX_REF1" MODIFY ("SERVICE_OBJID" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."PRT_T_CLRY_TX_REF1" MODIFY ("CCT_OBJID" NOT NULL ENABLE);
