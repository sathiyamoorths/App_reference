--------------------------------------------------------
--  Constraints for Table T_MAGUIRE_WLR_ASSOCIATED_ORDER
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."T_MAGUIRE_WLR_ASSOCIATED_ORDER" MODIFY ("ASSOCIATED_ORDERS" NOT NULL ENABLE);
