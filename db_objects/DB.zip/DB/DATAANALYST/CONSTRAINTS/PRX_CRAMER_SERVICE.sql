--------------------------------------------------------
--  Constraints for Table PRX_CRAMER_SERVICE
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRX_CRAMER_SERVICE" MODIFY ("SERVICEID" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."PRX_CRAMER_SERVICE" MODIFY ("SERVICENAME" NOT NULL ENABLE);
