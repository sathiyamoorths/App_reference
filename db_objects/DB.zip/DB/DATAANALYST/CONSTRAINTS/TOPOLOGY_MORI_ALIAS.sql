--------------------------------------------------------
--  Constraints for Table TOPOLOGY_MORI_ALIAS
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."TOPOLOGY_MORI_ALIAS" MODIFY ("CIRCUITID" NOT NULL ENABLE);
