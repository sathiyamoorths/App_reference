--------------------------------------------------------
--  Constraints for Table PRT_MSAN_CRAMER_SERV
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRT_MSAN_CRAMER_SERV" MODIFY ("SERVICEID" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."PRT_MSAN_CRAMER_SERV" MODIFY ("SERVICENAME" NOT NULL ENABLE);
