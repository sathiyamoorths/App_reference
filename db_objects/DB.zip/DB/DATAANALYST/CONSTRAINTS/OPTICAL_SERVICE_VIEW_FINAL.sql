--------------------------------------------------------
--  Constraints for Table OPTICAL_SERVICE_VIEW_FINAL
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."OPTICAL_SERVICE_VIEW_FINAL" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
