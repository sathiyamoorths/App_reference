--------------------------------------------------------
--  Constraints for Table THUS_MPLS_SERVICE_VIEW
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."THUS_MPLS_SERVICE_VIEW" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
