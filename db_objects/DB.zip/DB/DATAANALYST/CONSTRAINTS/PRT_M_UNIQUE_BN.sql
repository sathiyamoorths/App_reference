--------------------------------------------------------
--  Constraints for Table PRT_M_UNIQUE_BN
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRT_M_UNIQUE_BN" MODIFY ("PROJECTID" NOT NULL ENABLE);
