--------------------------------------------------------
--  Constraints for Table DWDM_4200_NETWORK
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."DWDM_4200_NETWORK" MODIFY ("EXTRACTED_NAME" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."DWDM_4200_NETWORK" MODIFY ("SNC_NAME" NOT NULL ENABLE);
