--------------------------------------------------------
--  Constraints for Table HFD_T_EDGE
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."HFD_T_EDGE" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."HFD_T_EDGE" MODIFY ("BT_SERVICE_ID" NOT NULL ENABLE);
