--------------------------------------------------------
--  Constraints for Table CLEAN_BILLING_ACCOUNT_NO
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."CLEAN_BILLING_ACCOUNT_NO" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
