--------------------------------------------------------
--  Constraints for Table THUS_BB_DEMON_THUSSF_UNO
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."THUS_BB_DEMON_THUSSF_UNO" MODIFY ("THUSSF_HOSTNAME" NOT NULL ENABLE);
