--------------------------------------------------------
--  Constraints for Table IV_BLUE_SFDC_ACC_MAN
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."IV_BLUE_SFDC_ACC_MAN" MODIFY ("USERID" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."IV_BLUE_SFDC_ACC_MAN" MODIFY ("ACCOUNT_ID" NOT NULL ENABLE);
