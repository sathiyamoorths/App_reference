--------------------------------------------------------
--  Constraints for Table CROSS_REFERENCE_TEMP
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."CROSS_REFERENCE_TEMP" MODIFY ("CIRCUITNAME" NOT NULL ENABLE);
