--------------------------------------------------------
--  Constraints for Table P102_WLR_MAGUIRE
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."P102_WLR_MAGUIRE" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
