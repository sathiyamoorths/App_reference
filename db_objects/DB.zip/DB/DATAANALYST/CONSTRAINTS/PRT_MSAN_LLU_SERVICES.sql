--------------------------------------------------------
--  Constraints for Table PRT_MSAN_LLU_SERVICES
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRT_MSAN_LLU_SERVICES" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."PRT_MSAN_LLU_SERVICES" MODIFY ("BT_SERVICE_ID" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."PRT_MSAN_LLU_SERVICES" MODIFY ("PRODUCT_ID" NOT NULL ENABLE);
