--------------------------------------------------------
--  Constraints for Table PRTO_T_ADDRESS_22_11_19
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRTO_T_ADDRESS_22_11_19" MODIFY ("SITE_OBJID" NOT NULL ENABLE);
