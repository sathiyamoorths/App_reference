--------------------------------------------------------
--  Constraints for Table PRT_U_SERVICEVIEW_BKP8THJUNE
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRT_U_SERVICEVIEW_BKP8THJUNE" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
