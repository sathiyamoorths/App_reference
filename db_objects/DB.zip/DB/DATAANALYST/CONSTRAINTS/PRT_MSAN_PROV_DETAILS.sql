--------------------------------------------------------
--  Constraints for Table PRT_MSAN_PROV_DETAILS
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRT_MSAN_PROV_DETAILS" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
