--------------------------------------------------------
--  Constraints for Table APM_SERVICEVIEW_TEMP
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."APM_SERVICEVIEW_TEMP" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
