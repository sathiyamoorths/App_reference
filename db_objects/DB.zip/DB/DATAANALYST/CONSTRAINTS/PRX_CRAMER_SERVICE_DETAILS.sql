--------------------------------------------------------
--  Constraints for Table PRX_CRAMER_SERVICE_DETAILS
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRX_CRAMER_SERVICE_DETAILS" MODIFY ("SERVICEID" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."PRX_CRAMER_SERVICE_DETAILS" MODIFY ("SERVICENAME" NOT NULL ENABLE);
