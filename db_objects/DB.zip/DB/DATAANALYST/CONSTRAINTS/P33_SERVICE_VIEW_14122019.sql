--------------------------------------------------------
--  Constraints for Table P33_SERVICE_VIEW_14122019
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."P33_SERVICE_VIEW_14122019" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
