--------------------------------------------------------
--  Constraints for Table T_MAGUIRE_WLR_EDGE_SERVICE
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."T_MAGUIRE_WLR_EDGE_SERVICE" MODIFY ("LINKID" NOT NULL ENABLE);
