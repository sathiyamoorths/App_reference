--------------------------------------------------------
--  Constraints for Table PX_OMARS
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PX_OMARS" MODIFY ("ORDER_MGT_REF" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."PX_OMARS" MODIFY ("DESCRIPTION" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."PX_OMARS" MODIFY ("OVERALL_JOB_STATUS" NOT NULL ENABLE);
