--------------------------------------------------------
--  Constraints for Table CRM_SERVICEVIEW_DRIV0_TMP
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."CRM_SERVICEVIEW_DRIV0_TMP" MODIFY ("PRT_SERVICE_ID" NOT NULL ENABLE);
