--------------------------------------------------------
--  Constraints for Table TM_MSAN_CRM
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."TM_MSAN_CRM" MODIFY ("TAIL_OBJID" NOT NULL ENABLE);
