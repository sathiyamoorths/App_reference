--------------------------------------------------------
--  Constraints for Table GREEN_MPLS_CRAMER_SERV
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."GREEN_MPLS_CRAMER_SERV" MODIFY ("SERVICEID" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."GREEN_MPLS_CRAMER_SERV" MODIFY ("SERVICENAME" NOT NULL ENABLE);
