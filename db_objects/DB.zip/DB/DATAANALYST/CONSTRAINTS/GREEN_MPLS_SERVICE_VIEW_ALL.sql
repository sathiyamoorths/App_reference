--------------------------------------------------------
--  Constraints for Table GREEN_MPLS_SERVICE_VIEW_ALL
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."GREEN_MPLS_SERVICE_VIEW_ALL" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
