--------------------------------------------------------
--  Constraints for Table THUS_DWDM_SERVICE_VIEW_ALL
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."THUS_DWDM_SERVICE_VIEW_ALL" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
