--------------------------------------------------------
--  Constraints for Table MAGUIRE_CRM6_BILLING_DETAIL_2
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."MAGUIRE_CRM6_BILLING_DETAIL_2" MODIFY ("BILLING_ACCOUNT_NO" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."MAGUIRE_CRM6_BILLING_DETAIL_2" MODIFY ("SOURCE_SYSTEM" NOT NULL ENABLE);
