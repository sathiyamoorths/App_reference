--------------------------------------------------------
--  Constraints for Table HFDG_KOSMOS_SERVICES
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."HFDG_KOSMOS_SERVICES" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
