--------------------------------------------------------
--  Constraints for Table HFDG_DUPLICATE_SERVICES
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."HFDG_DUPLICATE_SERVICES" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
