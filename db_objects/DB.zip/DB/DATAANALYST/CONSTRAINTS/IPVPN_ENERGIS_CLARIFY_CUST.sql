--------------------------------------------------------
--  Constraints for Table IPVPN_ENERGIS_CLARIFY_CUST
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."IPVPN_ENERGIS_CLARIFY_CUST" MODIFY ("SERVICE_NAME" NOT NULL ENABLE);
