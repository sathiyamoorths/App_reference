--------------------------------------------------------
--  Constraints for Table THUS_MPLS_NODE_INV_MAPPING
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."THUS_MPLS_NODE_INV_MAPPING" MODIFY ("MPLS_NODE_NAME" NOT NULL ENABLE);
