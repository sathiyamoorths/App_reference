--------------------------------------------------------
--  Constraints for Table THUS_BB_DEMON_PRM_EDGE
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."THUS_BB_DEMON_PRM_EDGE" MODIFY ("BT_SERVICE_ID" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."THUS_BB_DEMON_PRM_EDGE" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
