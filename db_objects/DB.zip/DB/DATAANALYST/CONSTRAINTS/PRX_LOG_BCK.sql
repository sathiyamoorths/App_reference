--------------------------------------------------------
--  Constraints for Table PRX_LOG_BCK
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRX_LOG_BCK" MODIFY ("ENTITY" NOT NULL ENABLE);
