--------------------------------------------------------
--  Constraints for Table PRT_BT_OLO_REF
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRT_BT_OLO_REF" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
