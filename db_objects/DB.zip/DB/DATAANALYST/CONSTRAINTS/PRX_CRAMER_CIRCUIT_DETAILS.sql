--------------------------------------------------------
--  Constraints for Table PRX_CRAMER_CIRCUIT_DETAILS
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRX_CRAMER_CIRCUIT_DETAILS" MODIFY ("CIRCUITID" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."PRX_CRAMER_CIRCUIT_DETAILS" MODIFY ("S_CIRCUITNAME" NOT NULL ENABLE);
