--------------------------------------------------------
--  Constraints for Table P33_SERVICE_VIEW
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."P33_SERVICE_VIEW" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
