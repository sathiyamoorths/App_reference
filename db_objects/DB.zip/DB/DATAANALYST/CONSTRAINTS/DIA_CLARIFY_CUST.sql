--------------------------------------------------------
--  Constraints for Table DIA_CLARIFY_CUST
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."DIA_CLARIFY_CUST" MODIFY ("SERVICE_NAME" NOT NULL ENABLE);
