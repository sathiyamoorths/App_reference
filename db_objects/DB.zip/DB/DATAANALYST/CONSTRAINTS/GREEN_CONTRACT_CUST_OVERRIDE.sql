--------------------------------------------------------
--  Constraints for Table GREEN_CONTRACT_CUST_OVERRIDE
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."GREEN_CONTRACT_CUST_OVERRIDE" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
