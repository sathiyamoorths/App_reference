--------------------------------------------------------
--  Constraints for Table PRT_CLARIFY_CASE_NOTES
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRT_CLARIFY_CASE_NOTES" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
