--------------------------------------------------------
--  Constraints for Table P104_SIEBEL_MAGUIRE
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."P104_SIEBEL_MAGUIRE" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
