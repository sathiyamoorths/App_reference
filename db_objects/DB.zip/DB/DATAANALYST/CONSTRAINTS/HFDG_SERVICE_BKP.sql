--------------------------------------------------------
--  Constraints for Table HFDG_SERVICE_BKP
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."HFDG_SERVICE_BKP" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
