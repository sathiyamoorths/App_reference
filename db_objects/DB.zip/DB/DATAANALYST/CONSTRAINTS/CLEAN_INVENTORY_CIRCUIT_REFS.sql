--------------------------------------------------------
--  Constraints for Table CLEAN_INVENTORY_CIRCUIT_REFS
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."CLEAN_INVENTORY_CIRCUIT_REFS" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
