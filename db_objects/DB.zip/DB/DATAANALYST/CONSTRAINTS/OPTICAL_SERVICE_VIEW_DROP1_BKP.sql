--------------------------------------------------------
--  Constraints for Table OPTICAL_SERVICE_VIEW_DROP1_BKP
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."OPTICAL_SERVICE_VIEW_DROP1_BKP" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
