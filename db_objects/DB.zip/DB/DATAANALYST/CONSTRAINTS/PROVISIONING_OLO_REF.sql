--------------------------------------------------------
--  Constraints for Table PROVISIONING_OLO_REF
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PROVISIONING_OLO_REF" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
