--------------------------------------------------------
--  Constraints for Table EDGE_PRICE_CAL
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."EDGE_PRICE_CAL" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."EDGE_PRICE_CAL" MODIFY ("BT_SERVICE_ID" NOT NULL ENABLE);
