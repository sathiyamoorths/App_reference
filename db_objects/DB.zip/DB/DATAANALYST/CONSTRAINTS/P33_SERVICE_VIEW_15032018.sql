--------------------------------------------------------
--  Constraints for Table P33_SERVICE_VIEW_15032018
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."P33_SERVICE_VIEW_15032018" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
