--------------------------------------------------------
--  Constraints for Table PRT_L_CR_NODE_OPTICAL
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRT_L_CR_NODE_OPTICAL" MODIFY ("NODEID" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."PRT_L_CR_NODE_OPTICAL" MODIFY ("NODENAME" NOT NULL ENABLE);
