--------------------------------------------------------
--  Constraints for Table PRT_U_SERVICEVIEW_31082018
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRT_U_SERVICEVIEW_31082018" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
