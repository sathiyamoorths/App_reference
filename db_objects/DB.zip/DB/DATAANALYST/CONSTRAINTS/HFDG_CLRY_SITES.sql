--------------------------------------------------------
--  Constraints for Table HFDG_CLRY_SITES
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."HFDG_CLRY_SITES" MODIFY ("SITE_OBJID" NOT NULL ENABLE);
