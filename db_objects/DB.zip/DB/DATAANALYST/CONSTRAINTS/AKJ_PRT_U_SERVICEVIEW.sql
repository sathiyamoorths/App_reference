--------------------------------------------------------
--  Constraints for Table AKJ_PRT_U_SERVICEVIEW
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."AKJ_PRT_U_SERVICEVIEW" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
