--------------------------------------------------------
--  Constraints for Table CL_ASSOC_ORDERS
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."CL_ASSOC_ORDERS" MODIFY ("LINKID" NOT NULL ENABLE);
