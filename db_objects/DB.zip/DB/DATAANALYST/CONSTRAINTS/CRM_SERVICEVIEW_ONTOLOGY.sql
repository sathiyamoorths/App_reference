--------------------------------------------------------
--  Constraints for Table CRM_SERVICEVIEW_ONTOLOGY
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."CRM_SERVICEVIEW_ONTOLOGY" MODIFY ("PRT_SERVICE_ID" NOT NULL ENABLE);
