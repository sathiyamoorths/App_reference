--------------------------------------------------------
--  Constraints for Table MSAN_CEASE_SERVICE_OVERRIDE
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."MSAN_CEASE_SERVICE_OVERRIDE" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
