--------------------------------------------------------
--  Constraints for Table CL_CLRY_SRVC_TMP
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."CL_CLRY_SRVC_TMP" MODIFY ("SERVICE_OBJID" NOT NULL ENABLE);
