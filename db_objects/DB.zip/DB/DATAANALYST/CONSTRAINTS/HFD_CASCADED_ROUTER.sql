--------------------------------------------------------
--  Constraints for Table HFD_CASCADED_ROUTER
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."HFD_CASCADED_ROUTER" MODIFY ("SERVICE_OBJID" NOT NULL ENABLE);
