--------------------------------------------------------
--  Constraints for Table AS2529_EDGE_SERVICE
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."AS2529_EDGE_SERVICE" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."AS2529_EDGE_SERVICE" MODIFY ("BT_SERVICE_ID" NOT NULL ENABLE);
