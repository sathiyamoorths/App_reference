--------------------------------------------------------
--  Constraints for Table THUS_BB_RESELLER_EDGE_SERVICE
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."THUS_BB_RESELLER_EDGE_SERVICE" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."THUS_BB_RESELLER_EDGE_SERVICE" MODIFY ("BT_SERVICE_ID" NOT NULL ENABLE);
