--------------------------------------------------------
--  Constraints for Table P105_CRM6_MAGUIRE
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."P105_CRM6_MAGUIRE" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
