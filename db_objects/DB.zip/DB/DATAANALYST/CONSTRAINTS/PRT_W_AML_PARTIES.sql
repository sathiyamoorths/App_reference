--------------------------------------------------------
--  Constraints for Table PRT_W_AML_PARTIES
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRT_W_AML_PARTIES" MODIFY ("OBJID" NOT NULL ENABLE);
