--------------------------------------------------------
--  Constraints for Table P33_NET_TEMP
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."P33_NET_TEMP" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
