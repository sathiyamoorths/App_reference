--------------------------------------------------------
--  Constraints for Table P33_SSBS_CUSNORN_DETAILS_CLEAN
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."P33_SSBS_CUSNORN_DETAILS_CLEAN" MODIFY ("TNBS_NUMBER" NOT NULL ENABLE);
