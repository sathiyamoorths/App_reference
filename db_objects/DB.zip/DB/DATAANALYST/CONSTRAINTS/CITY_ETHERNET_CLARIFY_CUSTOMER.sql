--------------------------------------------------------
--  Constraints for Table CITY_ETHERNET_CLARIFY_CUSTOMER
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."CITY_ETHERNET_CLARIFY_CUSTOMER" MODIFY ("SERVICE_NAME" NOT NULL ENABLE);
