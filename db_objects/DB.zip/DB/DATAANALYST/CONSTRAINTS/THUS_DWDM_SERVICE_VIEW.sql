--------------------------------------------------------
--  Constraints for Table THUS_DWDM_SERVICE_VIEW
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."THUS_DWDM_SERVICE_VIEW" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
