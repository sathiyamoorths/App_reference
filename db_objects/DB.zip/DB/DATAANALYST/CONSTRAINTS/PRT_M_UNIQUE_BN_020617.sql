--------------------------------------------------------
--  Constraints for Table PRT_M_UNIQUE_BN_020617
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRT_M_UNIQUE_BN_020617" MODIFY ("PROJECTID" NOT NULL ENABLE);
