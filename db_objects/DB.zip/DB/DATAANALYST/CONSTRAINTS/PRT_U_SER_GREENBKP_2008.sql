--------------------------------------------------------
--  Constraints for Table PRT_U_SER_GREENBKP_2008
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRT_U_SER_GREENBKP_2008" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
