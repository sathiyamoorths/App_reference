--------------------------------------------------------
--  Constraints for Table T_MAGUIRE_WLR_POS_SERVICE
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."T_MAGUIRE_WLR_POS_SERVICE" MODIFY ("LINKID" NOT NULL ENABLE);
