--------------------------------------------------------
--  Constraints for Table LOCM_VRF
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."LOCM_VRF" MODIFY ("VRF_NAME" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."LOCM_VRF" MODIFY ("CIRCUITNAME" NOT NULL ENABLE);
