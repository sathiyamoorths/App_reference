--------------------------------------------------------
--  Constraints for Table TEMP1
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."TEMP1" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
