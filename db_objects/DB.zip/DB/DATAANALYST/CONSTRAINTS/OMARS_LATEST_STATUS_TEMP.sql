--------------------------------------------------------
--  Constraints for Table OMARS_LATEST_STATUS_TEMP
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."OMARS_LATEST_STATUS_TEMP" MODIFY ("ORDER_MGT_REF" NOT NULL ENABLE);
