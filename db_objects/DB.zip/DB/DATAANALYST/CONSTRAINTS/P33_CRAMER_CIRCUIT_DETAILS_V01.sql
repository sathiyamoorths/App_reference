--------------------------------------------------------
--  Constraints for Table P33_CRAMER_CIRCUIT_DETAILS_V01
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."P33_CRAMER_CIRCUIT_DETAILS_V01" MODIFY ("CIRCUITID" NOT NULL ENABLE);
