--------------------------------------------------------
--  Constraints for Table PRX_LOG
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRX_LOG" MODIFY ("ENTITY" NOT NULL ENABLE);
