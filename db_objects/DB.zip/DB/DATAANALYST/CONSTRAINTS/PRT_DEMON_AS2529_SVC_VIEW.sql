--------------------------------------------------------
--  Constraints for Table PRT_DEMON_AS2529_SVC_VIEW
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRT_DEMON_AS2529_SVC_VIEW" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
