--------------------------------------------------------
--  Constraints for Table HFDG_EDGE_OLO_TEMP
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."HFDG_EDGE_OLO_TEMP" MODIFY ("EDGE_SERVICE_ID" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."HFDG_EDGE_OLO_TEMP" MODIFY ("BT_SERVICE_ID" NOT NULL ENABLE);
