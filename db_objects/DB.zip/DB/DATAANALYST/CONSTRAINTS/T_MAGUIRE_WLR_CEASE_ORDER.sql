--------------------------------------------------------
--  Constraints for Table T_MAGUIRE_WLR_CEASE_ORDER
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."T_MAGUIRE_WLR_CEASE_ORDER" MODIFY ("CEASE_ORDER" NOT NULL ENABLE);
