--------------------------------------------------------
--  Constraints for Table THUS_DWDM_CRAMER_SERV
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."THUS_DWDM_CRAMER_SERV" MODIFY ("SERVICEID" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."THUS_DWDM_CRAMER_SERV" MODIFY ("SERVICENAME" NOT NULL ENABLE);
