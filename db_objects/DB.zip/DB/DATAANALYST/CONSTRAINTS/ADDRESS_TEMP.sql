--------------------------------------------------------
--  Constraints for Table ADDRESS_TEMP
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."ADDRESS_TEMP" MODIFY ("NODENAME" NOT NULL ENABLE);
