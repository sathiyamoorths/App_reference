--------------------------------------------------------
--  Constraints for Table T_MAGUIRE_WLR_PROVIDE_ORDER
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."T_MAGUIRE_WLR_PROVIDE_ORDER" MODIFY ("PROVIDE_ORDER" NOT NULL ENABLE);
