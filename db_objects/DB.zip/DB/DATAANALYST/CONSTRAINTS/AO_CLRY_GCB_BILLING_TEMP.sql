--------------------------------------------------------
--  Constraints for Table AO_CLRY_GCB_BILLING_TEMP
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."AO_CLRY_GCB_BILLING_TEMP" MODIFY ("CHARGE_TYPE_CODE" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."AO_CLRY_GCB_BILLING_TEMP" MODIFY ("CHARGE_ID" NOT NULL ENABLE);
