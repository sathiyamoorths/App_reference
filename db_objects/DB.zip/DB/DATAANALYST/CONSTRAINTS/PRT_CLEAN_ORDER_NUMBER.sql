--------------------------------------------------------
--  Constraints for Table PRT_CLEAN_ORDER_NUMBER
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRT_CLEAN_ORDER_NUMBER" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
