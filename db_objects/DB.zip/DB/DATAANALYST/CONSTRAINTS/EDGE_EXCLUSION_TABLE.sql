--------------------------------------------------------
--  Constraints for Table EDGE_EXCLUSION_TABLE
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."EDGE_EXCLUSION_TABLE" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
