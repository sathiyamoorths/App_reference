--------------------------------------------------------
--  Constraints for Table PRTO_T_C_CIRCUITS1M
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRTO_T_C_CIRCUITS1M" MODIFY ("CIRCUITID" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."PRTO_T_C_CIRCUITS1M" MODIFY ("S_CIRCUITNAME" NOT NULL ENABLE);
