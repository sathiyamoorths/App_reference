--------------------------------------------------------
--  Constraints for Table SERVICEVIEWBKP_280918
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."SERVICEVIEWBKP_280918" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
