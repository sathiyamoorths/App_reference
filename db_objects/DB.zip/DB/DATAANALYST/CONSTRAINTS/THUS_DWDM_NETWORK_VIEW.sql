--------------------------------------------------------
--  Constraints for Table THUS_DWDM_NETWORK_VIEW
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."THUS_DWDM_NETWORK_VIEW" MODIFY ("PRT_SERVICEID" NOT NULL ENABLE);
