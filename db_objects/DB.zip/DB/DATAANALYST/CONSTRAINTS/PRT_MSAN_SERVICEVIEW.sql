--------------------------------------------------------
--  Constraints for Table PRT_MSAN_SERVICEVIEW
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRT_MSAN_SERVICEVIEW" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
