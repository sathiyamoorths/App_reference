--------------------------------------------------------
--  Constraints for Table EDGE_PID_TEMP
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."EDGE_PID_TEMP" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
