--------------------------------------------------------
--  Constraints for Table P96_L_CLRY2CRAMER
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."P96_L_CLRY2CRAMER" MODIFY ("CIRCUITID" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."P96_L_CLRY2CRAMER" MODIFY ("S_CIRCUITNAME" NOT NULL ENABLE);
