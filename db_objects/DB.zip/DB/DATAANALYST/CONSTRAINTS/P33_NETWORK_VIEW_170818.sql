--------------------------------------------------------
--  Constraints for Table P33_NETWORK_VIEW_170818
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."P33_NETWORK_VIEW_170818" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
