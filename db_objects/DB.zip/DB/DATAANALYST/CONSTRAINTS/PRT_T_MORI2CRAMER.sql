--------------------------------------------------------
--  Constraints for Table PRT_T_MORI2CRAMER
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRT_T_MORI2CRAMER" MODIFY ("CIRCUITID" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."PRT_T_MORI2CRAMER" MODIFY ("S_CIRCUITNAME" NOT NULL ENABLE);
