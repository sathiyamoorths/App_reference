--------------------------------------------------------
--  Constraints for Table IV_GREEN_POS_CUR_STATUS
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."IV_GREEN_POS_CUR_STATUS" MODIFY ("INS_STATUS" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."IV_GREEN_POS_CUR_STATUS" MODIFY ("INS_ID" NOT NULL ENABLE);
