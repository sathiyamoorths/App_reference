--------------------------------------------------------
--  Constraints for Table EDGE_PROV_DETAILS
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."EDGE_PROV_DETAILS" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."EDGE_PROV_DETAILS" MODIFY ("BT_SERVICE_ID" NOT NULL ENABLE);
