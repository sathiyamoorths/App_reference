--------------------------------------------------------
--  Constraints for Table PRTO_W_SERVICE2CASE
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRTO_W_SERVICE2CASE" MODIFY ("CLRY_SERVICE_OBJID" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."PRTO_W_SERVICE2CASE" MODIFY ("CASE_OBJID" NOT NULL ENABLE);
