--------------------------------------------------------
--  Constraints for Table IPVPN_ENERGIS_MAPPING_SERV
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."IPVPN_ENERGIS_MAPPING_SERV" MODIFY ("MASETERSERVICEID" NOT NULL ENABLE);
