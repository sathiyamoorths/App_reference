--------------------------------------------------------
--  Constraints for Table PRT_MSAN_SERVICEVIEW_FINAL
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRT_MSAN_SERVICEVIEW_FINAL" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
