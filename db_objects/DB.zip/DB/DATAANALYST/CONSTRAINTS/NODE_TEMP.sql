--------------------------------------------------------
--  Constraints for Table NODE_TEMP
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."NODE_TEMP" MODIFY ("CRAMER_CIRCUITS" NOT NULL ENABLE);
