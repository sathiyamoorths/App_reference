--------------------------------------------------------
--  Constraints for Table CLEAN_INV_CIRCUIT_REFS_TEMP
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."CLEAN_INV_CIRCUIT_REFS_TEMP" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
