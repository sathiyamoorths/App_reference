--------------------------------------------------------
--  Constraints for Table T_MAGUIRE_WLR_SSBS_STATUS
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."T_MAGUIRE_WLR_SSBS_STATUS" MODIFY ("START_DATE" NOT NULL ENABLE);
