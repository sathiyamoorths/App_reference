--------------------------------------------------------
--  Constraints for Table THUS_DWDM_SERVICE_VIEW_MPLS
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."THUS_DWDM_SERVICE_VIEW_MPLS" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
