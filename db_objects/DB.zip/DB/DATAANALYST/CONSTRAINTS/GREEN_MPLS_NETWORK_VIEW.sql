--------------------------------------------------------
--  Constraints for Table GREEN_MPLS_NETWORK_VIEW
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."GREEN_MPLS_NETWORK_VIEW" MODIFY ("ROUTER" NOT NULL ENABLE);
