--------------------------------------------------------
--  Constraints for Table PRTK_T_ARBOR_MAX_BILL_REF_NO
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRTK_T_ARBOR_MAX_BILL_REF_NO" MODIFY ("SUBSCR_NO" NOT NULL ENABLE);
