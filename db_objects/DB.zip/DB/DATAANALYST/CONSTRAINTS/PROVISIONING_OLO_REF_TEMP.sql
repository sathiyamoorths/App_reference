--------------------------------------------------------
--  Constraints for Table PROVISIONING_OLO_REF_TEMP
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PROVISIONING_OLO_REF_TEMP" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
