--------------------------------------------------------
--  Constraints for Table P22_ORDER2CIRCUIT
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."P22_ORDER2CIRCUIT" MODIFY ("S_CIRCUITNAME" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."P22_ORDER2CIRCUIT" MODIFY ("CIRCUITID" NOT NULL ENABLE);
