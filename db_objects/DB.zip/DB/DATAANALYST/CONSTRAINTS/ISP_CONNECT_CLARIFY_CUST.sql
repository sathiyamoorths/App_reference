--------------------------------------------------------
--  Constraints for Table ISP_CONNECT_CLARIFY_CUST
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."ISP_CONNECT_CLARIFY_CUST" MODIFY ("SERVICE_NAME" NOT NULL ENABLE);
