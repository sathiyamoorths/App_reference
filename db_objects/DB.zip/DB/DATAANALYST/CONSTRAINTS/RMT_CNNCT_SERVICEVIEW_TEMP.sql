--------------------------------------------------------
--  Constraints for Table RMT_CNNCT_SERVICEVIEW_TEMP
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."RMT_CNNCT_SERVICEVIEW_TEMP" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
