--------------------------------------------------------
--  Constraints for Table CRAMER_TOP_CIRCUIT
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."CRAMER_TOP_CIRCUIT" MODIFY ("CRAMER_ACTUAL_CIRCUITID" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."CRAMER_TOP_CIRCUIT" MODIFY ("CRAMER_ACTUAL_CIRCUITNAME" NOT NULL ENABLE);
