--------------------------------------------------------
--  Constraints for Table PRTO_W_LINK2CIRCUIT
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRTO_W_LINK2CIRCUIT" MODIFY ("LINKID" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."PRTO_W_LINK2CIRCUIT" MODIFY ("CIRCUITID" NOT NULL ENABLE);
