--------------------------------------------------------
--  Constraints for Table CRM_SERVICEVIEW
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."CRM_SERVICEVIEW" MODIFY ("PRT_SERVICE_ID" NOT NULL ENABLE);
