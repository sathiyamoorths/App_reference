--------------------------------------------------------
--  Constraints for Table OPTICAL_SRVC_VW_FINL_DROP2_BKP
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."OPTICAL_SRVC_VW_FINL_DROP2_BKP" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
