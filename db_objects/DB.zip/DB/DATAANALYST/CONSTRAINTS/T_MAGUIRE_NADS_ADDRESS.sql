--------------------------------------------------------
--  Constraints for Table T_MAGUIRE_NADS_ADDRESS
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."T_MAGUIRE_NADS_ADDRESS" MODIFY ("ADDRESS_START_DATE" NOT NULL ENABLE);
