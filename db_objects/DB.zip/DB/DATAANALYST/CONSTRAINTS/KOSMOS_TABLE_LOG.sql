--------------------------------------------------------
--  Constraints for Table KOSMOS_TABLE_LOG
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."KOSMOS_TABLE_LOG" MODIFY ("SCHEMA_NAME" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."KOSMOS_TABLE_LOG" MODIFY ("TABLE_NAME" NOT NULL ENABLE);
