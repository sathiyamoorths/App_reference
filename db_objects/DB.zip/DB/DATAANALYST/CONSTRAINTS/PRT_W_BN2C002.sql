--------------------------------------------------------
--  Constraints for Table PRT_W_BN2C002
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRT_W_BN2C002" MODIFY ("PROJECTID" NOT NULL ENABLE);
