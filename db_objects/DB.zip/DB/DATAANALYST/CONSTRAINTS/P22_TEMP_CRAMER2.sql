--------------------------------------------------------
--  Constraints for Table P22_TEMP_CRAMER2
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."P22_TEMP_CRAMER2" MODIFY ("S_CIRCUITNAME" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."P22_TEMP_CRAMER2" MODIFY ("CIRCUITID" NOT NULL ENABLE);
