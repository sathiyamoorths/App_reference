--------------------------------------------------------
--  Constraints for Table P100_EDGE_MAGUIRE
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."P100_EDGE_MAGUIRE" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
