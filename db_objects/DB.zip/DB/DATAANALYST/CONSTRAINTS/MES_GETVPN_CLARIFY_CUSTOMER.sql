--------------------------------------------------------
--  Constraints for Table MES_GETVPN_CLARIFY_CUSTOMER
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."MES_GETVPN_CLARIFY_CUSTOMER" MODIFY ("SERVICE_NAME" NOT NULL ENABLE);
