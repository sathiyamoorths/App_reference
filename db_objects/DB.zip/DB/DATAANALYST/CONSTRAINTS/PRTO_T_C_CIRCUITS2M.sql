--------------------------------------------------------
--  Constraints for Table PRTO_T_C_CIRCUITS2M
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRTO_T_C_CIRCUITS2M" MODIFY ("CIRCUITID" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."PRTO_T_C_CIRCUITS2M" MODIFY ("S_CIRCUITNAME" NOT NULL ENABLE);
