--------------------------------------------------------
--  Constraints for Table P101_CRM_MAGUIRE
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."P101_CRM_MAGUIRE" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
