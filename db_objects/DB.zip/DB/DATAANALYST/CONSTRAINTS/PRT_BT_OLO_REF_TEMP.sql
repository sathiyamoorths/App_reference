--------------------------------------------------------
--  Constraints for Table PRT_BT_OLO_REF_TEMP
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRT_BT_OLO_REF_TEMP" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
