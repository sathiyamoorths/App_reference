--------------------------------------------------------
--  Constraints for Table PRT_MSAN_INV_CKT_TEMP1
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRT_MSAN_INV_CKT_TEMP1" MODIFY ("SERVICEID" NOT NULL ENABLE);
