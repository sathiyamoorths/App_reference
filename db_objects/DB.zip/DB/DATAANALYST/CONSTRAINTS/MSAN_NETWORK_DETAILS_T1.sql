--------------------------------------------------------
--  Constraints for Table MSAN_NETWORK_DETAILS_T1
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."MSAN_NETWORK_DETAILS_T1" MODIFY ("ID" NOT NULL ENABLE);
