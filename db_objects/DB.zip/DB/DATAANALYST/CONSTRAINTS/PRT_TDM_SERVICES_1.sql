--------------------------------------------------------
--  Constraints for Table PRT_TDM_SERVICES_1
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRT_TDM_SERVICES_1" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
