--------------------------------------------------------
--  Constraints for Table CLEAN_ORDER_NUMBER
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."CLEAN_ORDER_NUMBER" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
