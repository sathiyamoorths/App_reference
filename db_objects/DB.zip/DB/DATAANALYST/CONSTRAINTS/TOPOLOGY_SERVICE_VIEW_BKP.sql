--------------------------------------------------------
--  Constraints for Table TOPOLOGY_SERVICE_VIEW_BKP
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."TOPOLOGY_SERVICE_VIEW_BKP" MODIFY ("SERVICENAME" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."TOPOLOGY_SERVICE_VIEW_BKP" MODIFY ("SERVICEID" NOT NULL ENABLE);
