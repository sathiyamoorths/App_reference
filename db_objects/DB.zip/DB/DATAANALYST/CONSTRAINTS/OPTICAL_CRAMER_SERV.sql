--------------------------------------------------------
--  Constraints for Table OPTICAL_CRAMER_SERV
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."OPTICAL_CRAMER_SERV" MODIFY ("SERVICEID" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."OPTICAL_CRAMER_SERV" MODIFY ("SERVICENAME" NOT NULL ENABLE);
