--------------------------------------------------------
--  Constraints for Table EDGE_ORDER_DETAILS
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."EDGE_ORDER_DETAILS" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
