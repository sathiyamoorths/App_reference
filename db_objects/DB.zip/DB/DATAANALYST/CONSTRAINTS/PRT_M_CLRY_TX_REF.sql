--------------------------------------------------------
--  Constraints for Table PRT_M_CLRY_TX_REF
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRT_M_CLRY_TX_REF" MODIFY ("SERVICE_OBJID" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."PRT_M_CLRY_TX_REF" MODIFY ("CCT_OBJID" NOT NULL ENABLE);
