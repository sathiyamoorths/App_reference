--------------------------------------------------------
--  Constraints for Table IV_BLUE_SSBS_LATEST
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."IV_BLUE_SSBS_LATEST" MODIFY ("BN_NUMBER" NOT NULL ENABLE);
