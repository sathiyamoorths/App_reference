--------------------------------------------------------
--  Constraints for Table MSAN_NETWORK_DETAILS_T2
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."MSAN_NETWORK_DETAILS_T2" MODIFY ("ID" NOT NULL ENABLE);
