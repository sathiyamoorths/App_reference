--------------------------------------------------------
--  Constraints for Table PRT_T_SSBS_START
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRT_T_SSBS_START" MODIFY ("PROJECTID" NOT NULL ENABLE);
