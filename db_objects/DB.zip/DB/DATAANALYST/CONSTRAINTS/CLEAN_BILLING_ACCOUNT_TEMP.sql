--------------------------------------------------------
--  Constraints for Table CLEAN_BILLING_ACCOUNT_TEMP
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."CLEAN_BILLING_ACCOUNT_TEMP" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
