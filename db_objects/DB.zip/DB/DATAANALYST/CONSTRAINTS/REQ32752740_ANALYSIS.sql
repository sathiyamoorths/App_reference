--------------------------------------------------------
--  Constraints for Table REQ32752740_ANALYSIS
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."REQ32752740_ANALYSIS" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
