--------------------------------------------------------
--  Constraints for Table PRX_CRAMER_CIRCUIT
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRX_CRAMER_CIRCUIT" MODIFY ("CIRCUITID" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."PRX_CRAMER_CIRCUIT" MODIFY ("S_CIRCUITNAME" NOT NULL ENABLE);
