--------------------------------------------------------
--  Constraints for Table PRT_MSAN_CIRCUIT
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRT_MSAN_CIRCUIT" MODIFY ("CIRCUITNAME" NOT NULL ENABLE);
