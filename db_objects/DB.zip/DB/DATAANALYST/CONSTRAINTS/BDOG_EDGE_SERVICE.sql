--------------------------------------------------------
--  Constraints for Table BDOG_EDGE_SERVICE
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."BDOG_EDGE_SERVICE" MODIFY ("BT_SERVICE_ID" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."BDOG_EDGE_SERVICE" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
