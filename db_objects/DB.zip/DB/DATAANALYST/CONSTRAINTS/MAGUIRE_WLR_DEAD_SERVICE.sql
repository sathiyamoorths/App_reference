--------------------------------------------------------
--  Constraints for Table MAGUIRE_WLR_DEAD_SERVICE
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."MAGUIRE_WLR_DEAD_SERVICE" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
