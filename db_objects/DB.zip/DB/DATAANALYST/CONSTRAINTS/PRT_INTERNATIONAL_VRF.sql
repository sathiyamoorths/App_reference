--------------------------------------------------------
--  Constraints for Table PRT_INTERNATIONAL_VRF
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRT_INTERNATIONAL_VRF" MODIFY ("VRF_NAME" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."PRT_INTERNATIONAL_VRF" MODIFY ("CIRCUITNAME" NOT NULL ENABLE);
