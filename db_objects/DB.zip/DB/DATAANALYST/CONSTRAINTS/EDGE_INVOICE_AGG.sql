--------------------------------------------------------
--  Constraints for Table EDGE_INVOICE_AGG
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."EDGE_INVOICE_AGG" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."EDGE_INVOICE_AGG" MODIFY ("BT_SERVICE_ID" NOT NULL ENABLE);
