--------------------------------------------------------
--  Constraints for Table DWDM_4200_OVERRIDE
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."DWDM_4200_OVERRIDE" MODIFY ("EXTRACTED_NAME" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."DWDM_4200_OVERRIDE" MODIFY ("SNC_NAME" NOT NULL ENABLE);
