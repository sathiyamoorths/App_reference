--------------------------------------------------------
--  Constraints for Table MORI_MISSING_DEVICES
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."MORI_MISSING_DEVICES" MODIFY ("LOCATION_ID" NOT NULL ENABLE);
