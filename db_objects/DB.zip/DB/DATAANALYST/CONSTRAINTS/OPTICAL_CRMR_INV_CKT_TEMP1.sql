--------------------------------------------------------
--  Constraints for Table OPTICAL_CRMR_INV_CKT_TEMP1
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."OPTICAL_CRMR_INV_CKT_TEMP1" MODIFY ("SERVICEID" NOT NULL ENABLE);
