--------------------------------------------------------
--  Constraints for Table PRT_L_LOCM_LOCTYPE
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRT_L_LOCM_LOCTYPE" MODIFY ("DESCRIPTION" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."PRT_L_LOCM_LOCTYPE" MODIFY ("LOCATION_TYPE" NOT NULL ENABLE);
