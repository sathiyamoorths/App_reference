--------------------------------------------------------
--  Constraints for Table REDSTREAM_IP_NETWORK_VIEW
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."REDSTREAM_IP_NETWORK_VIEW" MODIFY ("ROUTER" NOT NULL ENABLE);
