--------------------------------------------------------
--  Constraints for Table P96_TEMP3
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."P96_TEMP3" MODIFY ("S_CIRCUITNAME" NOT NULL ENABLE);
