--------------------------------------------------------
--  Constraints for Table CLRY_CIRCUIT2TAIL
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."CLRY_CIRCUIT2TAIL" MODIFY ("CIRCUIT_ID" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."CLRY_CIRCUIT2TAIL" MODIFY ("TAIL_OBJID" NOT NULL ENABLE);
