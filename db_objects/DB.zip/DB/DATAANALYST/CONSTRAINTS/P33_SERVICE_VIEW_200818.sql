--------------------------------------------------------
--  Constraints for Table P33_SERVICE_VIEW_200818
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."P33_SERVICE_VIEW_200818" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
