--------------------------------------------------------
--  Constraints for Table C361_CLRY_SERVICE1
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."C361_CLRY_SERVICE1" MODIFY ("SERVICE_OBJID" NOT NULL ENABLE);
