--------------------------------------------------------
--  Constraints for Table DEMON_SS_SERVICEVIEW_TEMP
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."DEMON_SS_SERVICEVIEW_TEMP" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
