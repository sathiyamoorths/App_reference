--------------------------------------------------------
--  Constraints for Table CRAMER_CROSS_REFERENCE
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."CRAMER_CROSS_REFERENCE" MODIFY ("CRAMER_ACTUAL_CIRCUITID" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."CRAMER_CROSS_REFERENCE" MODIFY ("CRAMER_ACTUAL_CIRCUITNAME" NOT NULL ENABLE);
