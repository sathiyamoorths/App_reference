--------------------------------------------------------
--  Constraints for Table THUS_MPLS_SERVICE_VIEW0727
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."THUS_MPLS_SERVICE_VIEW0727" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
