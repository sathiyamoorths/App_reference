--------------------------------------------------------
--  Constraints for Table OPTICAL_PROV_DETAILS
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."OPTICAL_PROV_DETAILS" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
