--------------------------------------------------------
--  Constraints for Table T_MAGUIRE_SAS_KEN_RC
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."T_MAGUIRE_SAS_KEN_RC" MODIFY ("BILL_REF_NO" NOT NULL ENABLE);
