--------------------------------------------------------
--  Constraints for Table P33_CLARIFY2CRAMER_MAP
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."P33_CLARIFY2CRAMER_MAP" MODIFY ("CLARIFY_SERVICE" NOT NULL ENABLE);
