--------------------------------------------------------
--  Constraints for Table PRT_U_SERVICEVIEW0727
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRT_U_SERVICEVIEW0727" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
