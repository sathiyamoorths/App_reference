--------------------------------------------------------
--  Constraints for Table PRTO_T_CLRY_SITE_PART
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRTO_T_CLRY_SITE_PART" MODIFY ("OBJID" NOT NULL ENABLE);
