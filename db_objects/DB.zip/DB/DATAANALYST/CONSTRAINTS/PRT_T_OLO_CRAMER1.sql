--------------------------------------------------------
--  Constraints for Table PRT_T_OLO_CRAMER1
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRT_T_OLO_CRAMER1" MODIFY ("START_CIRCUITID" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."PRT_T_OLO_CRAMER1" MODIFY ("START_CIRCUIT" NOT NULL ENABLE);
