--------------------------------------------------------
--  Constraints for Table PRTO_W_LINK_TERMINATE
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRTO_W_LINK_TERMINATE" MODIFY ("LINKID" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."PRTO_W_LINK_TERMINATE" MODIFY ("LINK_NAME" NOT NULL ENABLE);
