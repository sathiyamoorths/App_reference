--------------------------------------------------------
--  Constraints for Table CRM_SERVICEVIEW_DRIV
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."CRM_SERVICEVIEW_DRIV" MODIFY ("PRT_SERVICE_ID" NOT NULL ENABLE);
