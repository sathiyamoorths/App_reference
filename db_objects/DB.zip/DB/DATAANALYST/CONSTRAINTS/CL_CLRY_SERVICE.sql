--------------------------------------------------------
--  Constraints for Table CL_CLRY_SERVICE
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."CL_CLRY_SERVICE" MODIFY ("SERVICE_OBJID" NOT NULL ENABLE);
