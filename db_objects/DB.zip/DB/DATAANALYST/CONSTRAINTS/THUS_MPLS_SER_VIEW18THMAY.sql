--------------------------------------------------------
--  Constraints for Table THUS_MPLS_SER_VIEW18THMAY
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."THUS_MPLS_SER_VIEW18THMAY" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
