--------------------------------------------------------
--  Constraints for Table PRTO_T_C_CIRCUITS1
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRTO_T_C_CIRCUITS1" MODIFY ("CIRCUITID" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."PRTO_T_C_CIRCUITS1" MODIFY ("S_CIRCUITNAME" NOT NULL ENABLE);
