--------------------------------------------------------
--  Constraints for Table PRT_BT_STATUS_TEMP
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRT_BT_STATUS_TEMP" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
