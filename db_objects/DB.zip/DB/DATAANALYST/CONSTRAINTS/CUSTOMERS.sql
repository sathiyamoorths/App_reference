--------------------------------------------------------
--  Constraints for Table CUSTOMERS
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."CUSTOMERS" MODIFY ("CUSTOMER_ID" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."CUSTOMERS" MODIFY ("CUSTOMER_NAME" NOT NULL ENABLE);
