--------------------------------------------------------
--  Constraints for Table PRT_SWIFT_DATA_TAB
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRT_SWIFT_DATA_TAB" MODIFY ("CONTRACT_ID" NOT NULL ENABLE);
