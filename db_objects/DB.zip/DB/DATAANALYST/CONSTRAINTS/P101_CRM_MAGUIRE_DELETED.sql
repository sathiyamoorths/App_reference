--------------------------------------------------------
--  Constraints for Table P101_CRM_MAGUIRE_DELETED
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."P101_CRM_MAGUIRE_DELETED" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
