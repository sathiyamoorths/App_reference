--------------------------------------------------------
--  Constraints for Table AO_CLRY_OLO2BT_SERVICE
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."AO_CLRY_OLO2BT_SERVICE" MODIFY ("BT_SERVICE_ID" NOT NULL ENABLE);
