--------------------------------------------------------
--  Constraints for Table CRM_SITE_ADDRESS
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."CRM_SITE_ADDRESS" MODIFY ("PRT_SERVICE_ID" NOT NULL ENABLE);
