--------------------------------------------------------
--  Constraints for Table PRT_TDM_SERVICES_2
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRT_TDM_SERVICES_2" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
