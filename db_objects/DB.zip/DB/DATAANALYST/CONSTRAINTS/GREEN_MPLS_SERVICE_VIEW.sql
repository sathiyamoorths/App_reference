--------------------------------------------------------
--  Constraints for Table GREEN_MPLS_SERVICE_VIEW
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."GREEN_MPLS_SERVICE_VIEW" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
