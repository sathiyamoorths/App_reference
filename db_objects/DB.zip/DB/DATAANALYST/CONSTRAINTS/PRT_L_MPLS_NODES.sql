--------------------------------------------------------
--  Constraints for Table PRT_L_MPLS_NODES
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRT_L_MPLS_NODES" MODIFY ("NODEID" NOT NULL ENABLE);
