--------------------------------------------------------
--  Constraints for Table PRT_U_SERVICEVIEW_TEMP
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRT_U_SERVICEVIEW_TEMP" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
