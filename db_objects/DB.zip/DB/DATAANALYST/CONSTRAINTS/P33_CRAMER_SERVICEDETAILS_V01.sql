--------------------------------------------------------
--  Constraints for Table P33_CRAMER_SERVICEDETAILS_V01
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."P33_CRAMER_SERVICEDETAILS_V01" MODIFY ("SERVICENAME" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."P33_CRAMER_SERVICEDETAILS_V01" MODIFY ("SERVICEID" NOT NULL ENABLE);
