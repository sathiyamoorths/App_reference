--------------------------------------------------------
--  Constraints for Table P96_CRAMER_CIRCUIT
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."P96_CRAMER_CIRCUIT" MODIFY ("CIRCUITID" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."P96_CRAMER_CIRCUIT" MODIFY ("S_CIRCUITNAME" NOT NULL ENABLE);
