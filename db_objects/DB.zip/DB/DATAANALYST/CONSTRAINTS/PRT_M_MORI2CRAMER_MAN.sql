--------------------------------------------------------
--  Constraints for Table PRT_M_MORI2CRAMER_MAN
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRT_M_MORI2CRAMER_MAN" MODIFY ("CIRCUITID" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."PRT_M_MORI2CRAMER_MAN" MODIFY ("S_CIRCUITNAME" NOT NULL ENABLE);
