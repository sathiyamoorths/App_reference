--------------------------------------------------------
--  Constraints for Table P901_BT_INVOICE
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."P901_BT_INVOICE" MODIFY ("BT_CIRCUIT_REF" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."P901_BT_INVOICE" ADD CONSTRAINT "P901_BT_INVOICE_PK" PRIMARY KEY ("BT_CIRCUIT_REF")
  USING INDEX  ENABLE;
