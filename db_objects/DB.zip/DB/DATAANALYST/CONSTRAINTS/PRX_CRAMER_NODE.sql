--------------------------------------------------------
--  Constraints for Table PRX_CRAMER_NODE
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRX_CRAMER_NODE" MODIFY ("NODEID" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."PRX_CRAMER_NODE" MODIFY ("NODENAME" NOT NULL ENABLE);
