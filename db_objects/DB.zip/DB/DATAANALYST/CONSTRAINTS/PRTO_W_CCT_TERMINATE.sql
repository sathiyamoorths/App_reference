--------------------------------------------------------
--  Constraints for Table PRTO_W_CCT_TERMINATE
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRTO_W_CCT_TERMINATE" MODIFY ("CIRCUITID" NOT NULL ENABLE);
