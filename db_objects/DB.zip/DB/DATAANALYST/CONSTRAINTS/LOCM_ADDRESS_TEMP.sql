--------------------------------------------------------
--  Constraints for Table LOCM_ADDRESS_TEMP
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."LOCM_ADDRESS_TEMP" MODIFY ("NODENAME" NOT NULL ENABLE);
