--------------------------------------------------------
--  Constraints for Table CONTACT_LITE_SERVICE_VIEW
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."CONTACT_LITE_SERVICE_VIEW" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
