--------------------------------------------------------
--  Constraints for Table PRTO_T_C_CIRCUITS3
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRTO_T_C_CIRCUITS3" MODIFY ("CIRCUITID" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."PRTO_T_C_CIRCUITS3" MODIFY ("S_CIRCUITNAME" NOT NULL ENABLE);
