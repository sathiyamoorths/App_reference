--------------------------------------------------------
--  Constraints for Table PRTO_T_C_CIRCUITS3M_10122018
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."PRTO_T_C_CIRCUITS3M_10122018" MODIFY ("CIRCUITID" NOT NULL ENABLE);
  ALTER TABLE "DATAANALYST"."PRTO_T_C_CIRCUITS3M_10122018" MODIFY ("S_CIRCUITNAME" NOT NULL ENABLE);
