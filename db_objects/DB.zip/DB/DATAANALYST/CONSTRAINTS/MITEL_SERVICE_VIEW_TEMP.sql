--------------------------------------------------------
--  Constraints for Table MITEL_SERVICE_VIEW_TEMP
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."MITEL_SERVICE_VIEW_TEMP" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
