--------------------------------------------------------
--  Constraints for Table DEMON_SERVICES
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."DEMON_SERVICES" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
