--------------------------------------------------------
--  Constraints for Table OPTICAL_SERVICE_VIEW
--------------------------------------------------------

  ALTER TABLE "DATAANALYST"."OPTICAL_SERVICE_VIEW" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
