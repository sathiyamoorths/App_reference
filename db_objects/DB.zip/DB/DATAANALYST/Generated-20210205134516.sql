--------------------------------------------------------
--  File created - Friday-February-05-2021   
--------------------------------------------------------
@F:\Data\DB\Dataanalyst\TABLES\WLR_QT_CALLS_LINES.sql
@F:\Data\DB\Dataanalyst\INDEXES\WLR_QT_CALLS_LINES_I1.sql
