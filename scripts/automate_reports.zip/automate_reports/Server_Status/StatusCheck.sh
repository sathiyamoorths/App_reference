#!\bin\bash

#######################################################################################################################################################################
#	Script Name : StatusCheck.ksh																      #	
#	Directory   : /opt/ontology/SIP/Server_Status														      #
#	Frequency   : Every Half an Hour															      #	
#	Author      : Muneeswaran Perumal ( Muneeswaran.Perumal@vodafone.com )											      #
#	Description : 																		      #	
#  		This Script Will check the status of all the EIM application servers and trigger a mail for application server status.				      #	
#																				      #	
#																				      #	
#######################################################################################################################################################################

file="/home/ontology/SIP/Server_Status/stat.properties"

if [ -f "$file" ]
then
    echo "$file found."
 
printf "\n"

DATE=`date "+%Y-%m-%d %H-%M-%S"`

echo "currenttimestamp: "$DATE>/home/ontology/SIP/Server_Status/sanity.txt

export ORACLE_HOME=/opt/oracle/product/12.1.0.client
export PATH=$PATH:/opt/oracle/product/12.1.0.client/bin
if echo "exit;" | /opt/oracle/product/12.1.0.client/bin/sqlplus PR_USER/PR_USER01@KONAP1-DB.ad.plc.cwintra.com:1521/KONAP1 2>&1 | grep -q "Connected to"
then echo KONAP1_DB Connection : Pass >>/home/ontology/SIP/Server_Status/sanity.txt
else echo KONAP1_DB Connection : Fail >>/home/ontology/SIP/Server_Status/sanity.txt
fi

while read -r line
do

	SERVER_NAME=$(echo "$line" | awk '{print $1}')
	SERVER_STATUS=$(echo "$line" | awk '{print $2}')
	STATUS=`curl -s --insecure --head -w %{http_code} $SERVER_STATUS -o /dev/null`
	printf "$SERVER_NAME	: "
	if [ "$STATUS" = 302 ] 
	then
		printf "Pass"
	else
		printf "Fail"
	fi
	printf "\n"
done <$file >>/home/ontology/SIP/Server_Status/sanity.txt
fi

#sleep for 1 minute and trigger the script which converts the output text file to html file

sleep 10

sh -x /home/ontology/SIP/Server_Status/convert_2_html_table.sh -d ":" -f /home/ontology/SIP/Server_Status/sanity.txt  > /home/ontology/SIP/Server_Status/sanity.html

#Sending Mail

(
  echo To: plielad.matlang@vodafone.com,Deepa.K1@vodafone.com,sathiyamoorthi.v@vodafone.com,naveenkumar.anbalagan@vodafone.com,mohanapriya.r@vodafone.com,lokesh.kumar@vodafone.com,revanth.velakapuram@vodafone.com,koushik.besi@vodafone.com
  echo From: TCSEIMServiceSupport@cw.com
  echo "Content-Type: text/html; "
  echo Subject: EIM Service Status
  echo
  cat /home/ontology/SIP/Server_Status/sanity.html
) | /usr/sbin/sendmail -t

sleep 10

#trigger the one click sanity for EIM

cd /home/ontology/SIP/Server_Status/

java -jar Oneclicksanity.jar > /home/ontology/SIP/Server_Status/oneclick.txt

