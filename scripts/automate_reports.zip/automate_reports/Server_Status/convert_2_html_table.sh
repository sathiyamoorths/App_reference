#!\bin\bash

#Comvert sanity.txt to sanity.html

NOARG=64

f_Usage () {
echo "Usage: $(basename $0) -d <delimiter> -f <delimited-file>"
}

while getopts d:f: OPTION
do
    case $OPTION in
        d)  DELIMITER=$OPTARG ;;
        f)  INFILE=$OPTARG ;;
    esac
done

[ "$#" -lt 2 ] && f_Usage && exit $NOARG

DEFAULTDELIMITER=","

SEPARATOR=${DELIMITER:-$DEFAULTDELIMITER}

if [ -f "${INFILE}" ]
        then
                printf "<table border="4" bordercolor=green width="80%" bgcolor=#d61b1b align=center>"
                sed "s/$SEPARATOR/<\/td><td>/g" $INFILE | while read line
                        do
                                printf "<tr><td>${line}</td></tr>"
                done
                printf "</table>"
                echo
fi


