#!/bin/sh

# Application name 

appName="Vodafone Carrier Service"

# Finding transaction status from the godel.log

DATE=`date +%Y-%m-%d`
transActionComplete=`grep "$DATE" /opt/SP/ontology/ontology_vcs/install/ontology-veblen-vcs-5.3.0.35777-799c843-24517/godel.log|grep "Transaction complete, data now visible - Pipeline: _default, Type: Scheduled transaction,  Triggered by 'opt/ontology/Ontology_WP2_P2/output',  Description: Enhancement Ongoing Recon"`

if [[ $transActionComplete == *"Transaction complete"* ]]; then
transAction="Completed"
else
transAction="Not Completed"
fi

# Finding the heap memory uasge

heapUtilized=$(ps -ef | grep java | grep ontology_vcs | awk '{print $2}' |xargs /usr/java/jdk1.8.0_71/bin/jstat -gc | awk ' NR==2 {split($0,a," "); sum=a[3]+a[4]+a[6]+a[8]; printf "%i", sum/1024/1024}')
maxHeap=$(ps -ef | grep java| grep ontology_vcs | grep -o "Xmx[0-9]*". |  sed  's/[^0-9]//g')
usedPercentage=$((100*$heapUtilized/$maxHeap))

echo "Max heap size is $maxHeap"
echo "Heap utilized is $heapUtilized"
echo "Heap utilized percentage is $usedPercentage"

# Overall status of the application(including trassaction status and heap memory utilization)

status="Pass"

# Inserting application name, tranaction status, heap memory usage and overall status of the application

export ORACLE_HOME=/opt/oracle/product/11.2.0.client
export PATH=$PATH:/opt/oracle/product/11.2.0.client/bin
cd /home/ontology/SIP/
/opt/oracle/product/11.2.0.client/bin/sqlplus snapuat/snapuat321@GBVLS-DB052.ad.plc.cwintra.com:1521/CPTAT1<<EOF

INSERT INTO SANITY(APPLICATION,TRANSACTION,MEMORY,STATUS) VALUES('$appName','$transAction','$usedPercentage','$status');
COMMIT;

exit
EOF

Intro="Hello Team"
End="Thanks & Regards"
End2="EIM Support"

if [ $usedPercentage -gt 80 ]
then

echo -e $Intro '\n''\n' 'Heap Memory for VCS:'$usedPercentage '\n''\n'$End '\n'$End2| mail -s "Heap memory Usage High" muneeswaran.perumal@vodafone.com eldho.baby@vodafone.com

fi
