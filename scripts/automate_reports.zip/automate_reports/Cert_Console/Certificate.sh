#!/bin/sh

# Issuer for Eiger application certificates
# Subject for Eiger application certificates
# Date for Eiger application certificates

# Load the data from .jks files

file="./appl.properties"

if [ -f "$file" ]
then
    echo "$file found."
 . $file

printf "\n"

while read -r line
do

	JKS_FILENAME=$(echo "$line" | awk '{print $1}')
	JKS_PASSWORD=$(echo "$line" | awk '{print $2}')

#t1=`/usr/java/jdk1.8.0_71/jre/bin/keytool -list -v -keystore $JKS_FILENAME  -storepass $JKS_PASSWORD |grep Valid | awk '{print $12" "$13" "$14" "$15" "$16" "$17}'`
#t2=`(date -d "-60 days")`

#echo $t1
#echo $t2

#if [ $t1 -ge $t2]; then 

	printf "Certificate	: "
	/usr/java/jdk1.8.0_71/jre/bin/keytool -list -v -keystore $JKS_FILENAME -storepass $JKS_PASSWORD |grep Issuer | grep -oP 'CN=\K[^,]+'
	printf "Issued By	: "
	/usr/java/jdk1.8.0_71/jre/bin/keytool -list -v -keystore $JKS_FILENAME -storepass $JKS_PASSWORD |grep Issuer | grep -oP 'O=\K[^,]+'
	printf "StartDate	: "
	/usr/java/jdk1.8.0_71/jre/bin/keytool -list -v -keystore $JKS_FILENAME -storepass $JKS_PASSWORD |grep Valid | awk '{print $5" "$4" "$8}'
	printf "EndDate	: "
	/usr/java/jdk1.8.0_71/jre/bin/keytool -list -v -keystore $JKS_FILENAME -storepass $JKS_PASSWORD |grep Valid | awk '{print $12" "$11" "$15}'
	printf "\n"


#fi
done <$file >Output.txt

fi

pem=`ls /opt/SP/ontology/certificates/*.pem`

# Load the data from .pem files

for i in $pem;
do 
	printf "Certificate	: "
	openssl x509 -issuer -noout -in $i | grep -oP 'CN=\K[^/]+' ;
	printf "Issued By	: "
	openssl x509 -issuer -noout -in $i | grep -oP 'O=\K[^/]+' ;
	printf "StartDate	: "
	openssl x509 -startdate -noout -in $i | grep -oP 'notBefore=\K[^GMT]+' | awk '{print $2" "$1" "$4}';
	printf "EndDate	: "
	openssl x509 -enddate -noout -in $i | grep -oP 'notAfter=\K[^GMT]+' | awk '{print $2" "$1" "$4}';
	printf "\n"
done >>Output.txt

cer=`ls /opt/SP/ontology/certificates/*.cer`

# Load the data from .cer files

for i in $cer;
do 
	printf "Certificate	: "
	openssl x509 -issuer -noout -in $i | grep -oP 'CN=\K[^/]+' ;
	printf "Issued By	: "
	openssl x509 -issuer -noout -in $i | grep -oP 'O=\K[^/]+' ;
	printf "StartDate	: "
	openssl x509 -startdate -noout -in $i | grep -oP 'notBefore=\K[^GMT]+' | awk '{print $2" "$1" "$4}';
	printf "EndDate	: "
	openssl x509 -enddate -noout -in $i | grep -oP 'notAfter=\K[^GMT]+' | awk '{print $2" "$1" "$4}';
	printf "\n"
done >>Output.txt

der=`ls /opt/SP/ontology/certificates/*.der`

# Load the data from .der files

for i in $der;
do 
	printf "Certificate	: "
	openssl x509 -issuer -noout -in $i | grep -oP 'CN=\K[^/]+' ;
	printf "Issued By	: "
	openssl x509 -issuer -noout -in $i | grep -oP 'O=\K[^/]+' ;
	printf "StartDate	: "
	openssl x509 -startdate -noout -in $i | grep -oP 'notBefore=\K[^GMT]+' | awk '{print $2" "$1" "$4}';
	printf "EndDate	: "
	openssl x509 -enddate -noout -in $i | grep -oP 'notAfter=\K[^GMT]+' | awk '{print $2" "$1" "$4}';
	printf "\n"
done >>Output.txt

crt=`ls /opt/SP/ontology/certificates/*.crt`

# Load the data from .crt files

for i in $crt;
do 
	printf "Certificate	: "
	openssl x509 -issuer -noout -in $i | grep -oP 'CN=\K[^/]+' ;
	printf "Issued By	: "
	openssl x509 -issuer -noout -in $i | grep -oP 'O=\K[^/]+' ;
	printf "StartDate	: "
	openssl x509 -startdate -noout -in $i | grep -oP 'notBefore=\K[^GMT]+' | awk '{print $2" "$1" "$4}';
	printf "EndDate	: "
	openssl x509 -enddate -noout -in $i | grep -oP 'notAfter=\K[^GMT]+' | awk '{print $2" "$1" "$4}';
	printf "\n"
done >>Output.txt

echo "$(grep -v "Certificate	: Issued By" Output.txt)" >Output.txt