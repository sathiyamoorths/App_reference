import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;
import java.lang.Object;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.sql.Date;
import java.net.InetAddress;
//import java.util.Date;

public class SimpleConnection{
	public static Connection dbConnection(){
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
		}catch(ClassNotFoundException e){
			e.printStackTrace();
		}
		Connection connection=null;
		String url="jdbc:oracle:thin:@(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=scan-gbswirac.hosts.plc.cwintra.com)(PORT=1521)))(CONNECT_DATA=(SERVICE_NAME=MINUCO_PROD)))";
		try {
			connection=DriverManager.getConnection(url,"eigermgr","v3rn1sh321");
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return connection;
		
	}
	
	public static void main(String args[]) {
		ArrayList certificate=new ArrayList();
		ArrayList IssuedBy=new ArrayList();
		ArrayList StartDate=new ArrayList();
		ArrayList EndDate=new ArrayList();
		
		String fileName = "Output.txt";
		String[] parts; 
		try{

			BufferedReader br = new BufferedReader(new FileReader(fileName));
			String line;
			while ((line = br.readLine()) != null) {
				if(!line.isEmpty()){
				parts=line.split(":");
				parts[0]=parts[0].trim();
				parts[1]=parts[1].trim();
				if(parts[0].equalsIgnoreCase("Certificate")){
					certificate.add(parts[1]);
				}
				else if(parts[0].equalsIgnoreCase("Issued By")){
					IssuedBy.add(parts[1]);
				}
				else if(parts[0].equalsIgnoreCase("StartDate")){
					StartDate.add(parts[1]);
				}
				else if(parts[0].equalsIgnoreCase("EndDate")){
					EndDate.add(parts[1]);
				}
				
				}
				
				
			}
			String contact="TCSITServiceSupport@vodafone.com";
			String component="NON EDGE";
			String sql = "TRUNCATE table cert";
			String hostname = InetAddress.getLocalHost().getHostName();
			//System.out.println(hostname);
			String insertTableSQL = "INSERT INTO CERT"
				+ "(CERTIFICATE_NAME,CERTIFICATE_ISSUED_BY,COMPONENT_NAME,CERTIFICATE_ISSUED_DATE,CERTIFICATE_EXPIRY_DATE,CONTACT,STATUS,HOSTNAME) VALUES"
				+ "(?,?,?,TO_CHAR(to_date(replace(?,' ','-'),'DD/MM/YY'),'mm/dd/yyyy'),TO_CHAR(to_date(replace(?,' ','-'),'DD/MM/YY'),'mm/dd/yyyy'),?,?,?)";

			Connection conn=null;
			Statement stmt = null;
			try{
					conn=SimpleConnection.dbConnection();
					stmt=conn.createStatement();
					stmt.executeUpdate(sql);
			} catch(SQLException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			long diffDays=0;
			PreparedStatement preparedStatement = null;
			for(int i=0;i<certificate.size();i++){				
				try {



					String dateStop = EndDate.get(i).toString();
					java.util.Date curent= new java.util.Date();
					
					java.util.Date d1 = null;
					java.util.Date d2 = null;
					//HH converts hour in 24 hours format (0-23), day calculation
					
					SimpleDateFormat format = new SimpleDateFormat("dd MMM yyyy");
					try {
					//d1 = format.parse();
					d2 = format.parse(dateStop);
					long diff = d2.getTime() - curent.getTime();
					diffDays = diff / (24 * 60 * 60 * 1000);
					System.out.println(format.parse(dateStop)+"   "+curent.getTime());
					System.out.println("diffDays"+diffDays);
					} catch (Exception e) {
						e.printStackTrace();
					}


					conn=SimpleConnection.dbConnection();
					preparedStatement = conn.prepareStatement(insertTableSQL);
					preparedStatement.setString(1, certificate.get(i).toString());
					preparedStatement.setString(2, IssuedBy.get(i).toString());
					preparedStatement.setString(3,component.toString());
					preparedStatement.setString(4,StartDate.get(i).toString());
					preparedStatement.setString(5,EndDate.get(i).toString());
					preparedStatement.setString(6,contact.toString());
					
					if (diffDays<=60 && diffDays>30){
						preparedStatement.setString(7,"AMBER");
					}
					else if (diffDays <=30){
						preparedStatement.setString(7,"RED");
					}	
					else{
						preparedStatement.setString(7,"GREEN");
					}

					preparedStatement.setString(8,hostname.toString());					

					// execute insert SQL stetement
					if (diffDays>-365)
					 {
					preparedStatement.executeUpdate();
					conn.commit();
				System.out.println("Record is inserted into CERT table!");
						}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}finally {

					if (preparedStatement != null) {
						try {
							preparedStatement.close();
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}

					if (conn != null) {
						try {
							conn.close();
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}

				}
				
				

			}

		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}

