#!/bin/bash


#Getting the certificate details from the Linux servers

cd /home/ontology/SIP/Cert_Console

sh /home/ontology/SIP/Cert_Console/Certificate.sh	

#Complie the java program and get the connection class for database

/usr/java/jdk1.7.0_21/bin/javac /home/ontology/SIP/Cert_Console/SimpleConnection.java

#Run the connection class for storing the db details with log file (corresponding date)

date >> /home/ontology/SIP/Cert_Console/CertificateMonitor.log

echo "--------------------------------" >> /home/ontology/SIP/Cert_Console/CertificateMonitor.log

java -cp .:/opt/oracle/product/11.2.0.client/jdbc/lib/ojdbc6.jar SimpleConnection >> /home/ontology/SIP/Cert_Console/CertificateMonitor.log


