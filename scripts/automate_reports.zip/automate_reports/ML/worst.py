import pysftp

myHostname = "UKQLP0VW.ad.plc.cwintra.com"
myUsername = "qs_admin"
myPassword = "qs@june2017"
cnoptsh=pysftp.CnOpts()
cnoptsh.hostkeys=None

with pysftp.Connection(host=myHostname, username=myUsername, password=myPassword, cnopts=cnoptsh) as sftp:
    sftp.cnopts.hostkeys = None
    print ("Connection succesfully stablished ... ")

    # Define the file that you want to download from the remote directory
    remoteFilePath = 'Documents\TASKS'

    # Define the local path where the file will be saved
    # or absolute "C:\Users\sdkca\Desktop\TaskExec.txt"
    localFilePath = '/home/ontology/ML/TaskExec.txt'

    sftp.get(remoteFilePath, localFilePath)
	
	 
