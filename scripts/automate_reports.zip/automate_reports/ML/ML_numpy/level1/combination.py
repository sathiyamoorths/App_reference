from itertools import permutations 
def magic(numList):
    s = ''.join(map(str, numList))
    return int(s)
a=459
b=500
l=[]
temp=[]
res = [int(x) for x in str(a)]

perm = permutations(res) 
  
# Print the obtained permutations 
for i in list(perm): 
    l.append(magic(i))

print(l)

for j in l :
    temp.append(j-b)
print(temp)

temp2=[]

for d in temp :
    if d > 0 :
        temp2.append(d)
number=min(temp2)
print(number)

l3=temp.index(number)

print(l[l3])




