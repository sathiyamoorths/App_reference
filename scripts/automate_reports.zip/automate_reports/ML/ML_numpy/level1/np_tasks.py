import numpy as np

print(np.__version__)			#Import numpy as np and see the version

print(np.arange(10))			#How to create a 1D array - Create a 1D array of numbers from 0 to 9

a=np.ones((3,3), dtype=bool)

print(a)				#How to create a boolean array 3x3

arr=np.arange(10)

print(arr[arr%2!=0])			#extract items by condition

arr=np.arange(10)

arr[arr%2!=0]=-1

print(arr)				#replace items by condition

arr=np.arange(10)

out=np.where(arr%2!=0,-1,arr)

print(out)				#replace items by condition without changing the original array

print(arr)				#original array

arr=np.arange(10)

s1=arr.reshape(2,5)			#2 rows 5 column

print(s1)

s2=arr.reshape(2,-1)			#2 rows and [-1 automatiocally decides the number of cols]

print(s1)

a=np.arange(10).reshape(2,-1)

b=np.repeat(1,10).reshape(2,-1)		#repeat value 1 into 10 times in the array

print(np.vstack([a,b]))			#stack two arrays vertically 

print(np.r_[a,b])			#other way of vstack where r represents row wise

print(np.concatenate([a,b],axis=0))	#other way of vstack where axis = 0 represents row wise

a=np.arange(10).reshape(2,-1)

b=np.repeat(1,10).reshape(2,-1)		#repeat value 1 into 10 times in the array

print(np.hstack([a,b]))			#stack two arrays vertically 

print(np.c_[a,b])			#other way of hstack where c represents row wise

print(np.concatenate([a,b],axis=1))	#other way of hstack where axis = 0 represents column wise

a=np.array([1,2,3])

res=np.r_[np.repeat(a,3),np.tile(a,3)]

print(res)				#generate custom sequence

a=np.array([1,2,3,2,3,4,3,4,5,6])
n=np.array([7,2,10,2,7,4,9,4,9,8])

res=np.intersect1d(a,b)			#get the common items between two numpy arrays

print(res)

a=np.array([1,2,3,4,5])
b=np.array([5,6,7,8,9])

res=np.setdiff1d(a,b)			#remove the one array those items that exist in another

print(res)

a=np.array([1,2,3,2,3,4,3,4,5,6])
b=np.array([7,2,10,2,7,4,9,4,9,8])

print(np.where(a==b))			#get the positions where elements of two arras match

a=np.array([2,6,1,9,10,3,27])

print(a[(a>=55) & (a<=10)])		#get all items between 5 and 10 from a

print(np.where((a>=5) & (a<=10)))	#other way of get items between 5 and 10 from a

print(np.where(np.logical_and(a>=5,a<=10)))	#other way of get items between 5 and 10 from a

def maxx(x,y):
	if x>=y:
		return x
	else:
		return y

pair_max=np.vectorize(maxx,otypes=[float])

a=np.array([5,7,9,8,6,4,5]
b=np.array([6,3,4,8,9,7,1])

pair_max(a,b)


arr = np.arange(9).reshape(3,3)

print(arr[:,[1,0,2]])			#Swap columns 1 and 2 in the array arr

arr = np.arange(9).reshape(3,3)

print(arr[[1,0,2],:])			#Swap rows 1 and 2 in the array arr

arr = np.arange(9).reshape(3,3)

print(arr[::-1])			#Reverse the rows of a 2D array arr

arr = np.arange(9).reshape(3,3)

print(arr[:,::-1])			#Reverse the columns of a 2D array arr

arr = np.arange(9).reshape(3,3)

print(np.random.uniform(5,10,size=(5,3))	#Create a 2D array of shape 5x3 to contain random decimal numbers between 5 and 10

arr=np.random.random([5,3])

np.set_printoptions(precision=3)		#Print or show only 3 decimal places of the numpy array rand_arr

