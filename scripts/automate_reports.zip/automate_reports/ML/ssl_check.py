from OpenSSL import crypto
import ssl

cert=ssl.get_server_certificate(('kosmos.internal.vodafone.com',8443))
x509=OpenSSL.crypto.load_certificate(OpenSSL.crypto.FILETYPE_PEM,cert)
print(x509.get_subject().get_components())
