s='A2B5BC3F2D1E3'

i=0
while(i<len(s)):
	if(not s[i].isdigit()):
		print(s[i],end='')
	else:
		print('\b',end='')
		print(s[i-1]*int(s[i]),end='')
	i=i+1