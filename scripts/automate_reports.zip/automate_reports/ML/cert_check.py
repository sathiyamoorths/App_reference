from OpenSSL import crypto

cert_file='/home/ontology/ML/certificate/cert_vcs-cims.enterprise.vodafone.com.pem'
cert=crypto.load_certificate(crypto.FILETYPE_PEM,open(cert_file).read())
subject=cert.get_subject()
print(subject)
issued_to=subject.CN
print('CN',issued_to)
issuer=cert.get_issuer()
print('Issuer',issuer)
issued_by=issuer.CN
print('Issued By',issued_by)
