a={1,2,9,7}
b={2,3,7,6,2,3}
k=a|b
print(k.sort())