
#! /bin/sh

sh /home/ontology/SIP/Package_Exec/SVC_INV/pkg_svcinv.sh

cp /home/ontology/SIP/Package_Exec/SVC_INV/PRT_Packages_Status_svcinv.xls /home/ontology/SIP/Package_Exec/SVC_INV/PRT_Packages_Status_svcinv.html

sh /home/ontology/SIP/Package_Exec/SVC_INV/Mail_svcinv.sh
