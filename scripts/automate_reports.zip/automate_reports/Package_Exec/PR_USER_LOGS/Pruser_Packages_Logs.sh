#! /bin/sh

export ORACLE_HOME=/opt/oracle/product/12.1.0.client
export PATH=$PATH:/opt/oracle/product/12.1.0.client/bin
cd /home/ontology/SIP/Package_Exec/PR_USER_LOGS/
/opt/oracle/product/12.1.0.client/bin/sqlplus PR_USER/PR_USER01@KONAP1-DB.ad.plc.cwintra.com:1521/KONAP1<<EOF
@Pruser.sql

exit
EOF