#!\bin\bash
(
  echo To: sathiyamoorthi.v@vodafone.com,lokesh.kumar@vodafone.com,plielad.matlang@vodafone.com,amarender.gunda@vodafone.com
  echo From: TCSEIMServiceSupport@cw.com
  echo "Content-Type: text/html; "
  echo Subject: PR_USER Package_Logs - FAILED `date`
  echo "<html>
  <head>
  <style type="text/css">
    table {
	background-color: #DCDCDC;
        padding-left: 5px;
        padding-bottom:3px;
        font-size:11px;
    }
    th {
	background-color: #4CAF50;
	color: white;
    }
  </style>
  </head>
  <body>"
  cat /home/ontology/SIP/Package_Exec/PR_USER_LOGS/Pruser_Packages_Logs.html
  echo "</body></html>"
) | /usr/sbin/sendmail -t