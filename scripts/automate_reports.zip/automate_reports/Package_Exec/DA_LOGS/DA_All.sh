
#! /bin/sh


export ORACLE_HOME=/opt/oracle/product/12.1.0.client
export PATH=$PATH:/opt/oracle/product/12.1.0.client/bin
cd /home/ontology/SIP/Package_Exec/DA_LOGS/
 
flagvalue=`/opt/oracle/product/12.1.0.client/bin/sqlplus -s DATAANALYST/DATAANALYST01@KONAP1-DB.ad.plc.cwintra.com:1521/KONAP1<< END
         

        WHENEVER SQLERROR EXIT sql.sqlcode; 
set serveroutput on;
	set pages 0;
	set head off;
	set linesize 100;
	set trimspool on;
	set feedback off; 
        set echo off;

select trim(count(status)) from PRT_DATA_PROCESSING_LOGS where  upper(STATUS) like '%FAIL%';
EXIT; 
END`



if [ $flagvalue -gt 0 ]

then

sh /home/ontology/SIP/Package_Exec/DA_LOGS/DA_Packages_Logs.sh

cp /home/ontology/SIP/Package_Exec/DA_LOGS/DA_Packages_Logs.xls /home/ontology/SIP/Package_Exec/DA_LOGS/DA_Packages_Logs.html

sh /home/ontology/SIP/Package_Exec/DA_LOGS/DA_Mail.sh

fi