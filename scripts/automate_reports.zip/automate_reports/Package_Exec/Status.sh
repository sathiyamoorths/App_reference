
#! /bin/sh

sh /home/ontology/SIP/Package_Exec/pkg.sh

cp /home/ontology/SIP/Package_Exec/PRT_Packages_Status.xls /home/ontology/SIP/Package_Exec/PRT_Packages_Status.html

sh /home/ontology/SIP/Package_Exec/Mail.sh
