
#! /bin/sh

sh /home/ontology/SIP/Package_Exec/DA_Packages_status.sh

cp /home/ontology/SIP/Package_Exec/DA_Packages_Status.xls /home/ontology/SIP/Package_Exec/DA_Packages_Status.html

sh /home/ontology/SIP/Package_Exec/DA_Mail.sh
