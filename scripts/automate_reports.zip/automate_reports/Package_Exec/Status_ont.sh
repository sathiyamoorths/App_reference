
#! /bin/sh

sh /home/ontology/SIP/Package_Exec/pkg_ont.sh

cp /home/ontology/SIP/Package_Exec/PRT_Packages_Status_ont.xls /home/ontology/SIP/Package_Exec/PRT_Packages_Status_ont.html

sh /home/ontology/SIP/Package_Exec/Mail_ont.sh
