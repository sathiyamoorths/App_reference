
#! /bin/sh


export ORACLE_HOME=/opt/oracle/product/12.1.0.client
export PATH=$PATH:/opt/oracle/product/12.1.0.client/bin
cd /home/ontology/SIP/Package_Exec/ONTOLOGY_LOGS/
 
flagvalue=`/opt/oracle/product/12.1.0.client/bin/sqlplus -s ONTOLOGY/ONTOLOGY01@KONAP1-DB.ad.plc.cwintra.com:1521/KONAP1<< END
         

        WHENEVER SQLERROR EXIT sql.sqlcode; 
set serveroutput on;
	set pages 0;
	set head off;
	set linesize 100;
	set trimspool on;
	set feedback off; 
        set echo off;

select trim(count(status)) from PRT_DATALOAD_LOGS where  upper(STATUS) like '%FAIL%' or upper(STATUS) like '%STOP%' and ENTITY <> 'COPY_SHAREDCCTCOUNTS';
EXIT; 
END`



if [ $flagvalue -gt 0 ]

then

sh /home/ontology/SIP/Package_Exec/ONTOLOGY_LOGS/Ontology_Packages_Logs.sh

cp /home/ontology/SIP/Package_Exec/ONTOLOGY_LOGS/Ontology_Packages_Logs.xls /home/ontology/SIP/Package_Exec/ONTOLOGY_LOGS/Ontology_Packages_Logs.html

sh /home/ontology/SIP/Package_Exec/ONTOLOGY_LOGS/Ontology_Mail.sh

fi