
#! /bin/sh

sh /home/ontology/SIP/Package_Exec/Query_output/pkg.sh

