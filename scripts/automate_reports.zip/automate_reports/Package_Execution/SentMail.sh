#!\bin\bash
(
  echo To: mohanapriya.r@vodafone.com,sathiyamoorthi.v@vodafone.com,lokesh.kumar@vodafone.com,georgios.kokkinopoulos@vodafone.com,samuel.blenkinsopp@vodafone.com,adam.raya@vodafone.com,adrian.white@vodafone.com,arunprakash.sekhar@vodafone.com,david.varley@vodafone.com,eva.marchetti@vodafone.com,jack.bulpin@vodafone.com,javier.jimenez@vodafone.com,nicola.varley@vodafone.com,rashmee.rajkumar1@vodafone.com,simon.smith1@vodafone.com,james.neill@vodafone.com,siddhartha.ghosh@vodafone.com,rakhi.das@vodafone.com,madhura.bandyopadhyay@vodafone.com,prateek.singh7@vodafone.com,chris.pige@vodafone.com,sagnik.sarkar@vodafone.com,amarender.gunda@vodafone.com
  echo From: TCSEIMServiceSupport@cw.com
  echo "Content-Type: text/html; "
  echo Subject: PRT_BOXI_Packages_Status_`date`
  echo "<html>
  <head>
  <style type="text/css">
    table {
	background-color: #DCDCDC;
        padding-left: 5px;
        padding-bottom:3px;
        font-size:11px;
    }
    th {
	background-color: #4CAF50;
	color: white;
    }
  </style>
  </head>
  <body>"
  cat /home/ontology/SIP/Package_Execution/PRT_BOXI_Packages_Status.html
  echo "</body></html>"
) | /usr/sbin/sendmail -t