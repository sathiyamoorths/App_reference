#! /bin/sh

sh /home/ontology/SIP/Package_Execution/populate_annot_pkg/populate_annot_packEx.sh

cp /home/ontology/SIP/Package_Execution/populate_annot_pkg/PRT_PopulateAnnot__Packages_Status.xls /home/ontology/SIP/Package_Execution/populate_annot_pkg/PRT_PopulateAnnot_Packages_Status.html

sh /home/ontology/SIP/Package_Execution/populate_annot_pkg/SentMail.sh
