#! /bin/sh

export ORACLE_HOME=/opt/oracle/product/12.1.0.client
export PATH=$PATH:/opt/oracle/product/12.1.0.client/bin
cd /home/ontology/SIP/Package_Execution/populate_annot_pkg
/opt/oracle/product/12.1.0.client/bin/sqlplus ONTOLOGY/ONTOLOGY01@KONAP1-DB.ad.plc.cwintra.com:1521/KONAP1<<EOF
@newPackage.sql
exit
EOF





