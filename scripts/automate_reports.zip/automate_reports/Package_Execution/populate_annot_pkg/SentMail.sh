#!\bin\bash
(
  echo To: mohanapriya.r@vodafone.com,sathiyamoorthi.v@vodafone.com,lokesh.kumar@vodafone.com,plielad.matlang@vodafone.com,amarender.gunda@vodafone.com
  echo From: TCSEIMServiceSupport@cw.com
  echo "Content-Type: text/html; "
  echo Subject: PRT_PopolautAnnotation_Packages_Status_`date`
  echo "<html>
  <head>
  <style type="text/css">
    table {
	background-color: #DCDCDC;
        padding-left: 5px;
        padding-bottom:3px;
        font-size:11px;
    }
    th {
	background-color: #4CAF50;
	color: white;
    }
  </style>
  </head>
  <body>"
  cat /home/ontology/SIP/Package_Execution/populate_annot_pkg/PRT_PopulateAnnot_Packages_Status.html
  echo "</body></html>"
) | /usr/sbin/sendmail -t
