import urllib.request
import time
timing=time.strftime("%Y-%m-%d %H.%M")
import ssl
ssl._create_default_https_context = ssl._create_unverified_context
import os
import requests

def server_check(ip_address):
    return os.system('ping '+ip_address+'') == 0

def url_check(url):
    return urllib.request.urlopen(url).getcode() == 200

kosmos_server=['10.196.216.157','10.196.156.54','10.196.216.33']
server_status=[]

for i in range(len(kosmos_server)):
	server_status.append(server_check(kosmos_server[i]))

server_ip_and_status = dict(zip(kosmos_server,server_status))
print(server_ip_and_status)


url_name=['Server1','Server2','Server3']
url_list=['https://kosmos.internal.vodafone.com:8443/ontoscope/login','https://prtoolkit.direct.cwintra.com:8443/ontoscope/login','https://prtoolkit-proddataload.direct.cwintra.com:8443/ontoscope/login']
url_status=[]
url_color=[]
count=0

for i in range(len(url_list)):
    url_status.append(url_check(url_list[i]))

url_list_and_status = dict(zip(url_list,url_status))
print(url_list_and_status)

'''    fout = "sanity.txt"
    fo = open(fout, "w")
    fo.write('currenttimestamp  : '+ str(timing) + '\n')
    for k, v in dictionary.items():
        fo.write(str(k) + '     : '+ str(v) + '\n')
    fo.close()'''

def check_ssl(url):
    try:
        req = requests.get(url, verify=True)
        print(url + ' has a valid SSL certificate!')
    except requests.exceptions.SSLError:
        print(url + ' has INVALID SSL certificate!')

check_ssl('https://kosmos.internal.vodafone.com:8443/ontoscope/login')
check_ssl('https://prtoolkit.direct.cwintra.com:8443/ontoscope/login')
check_ssl('https://prtoolkit-proddataload.direct.cwintra.com:8443/ontoscope/login')
check_ssl('https://csview.enterprise.vodafone.com:8443/ontoscope/login')
check_ssl('https://vcs-cims.enterprise.vodafone.com:8444/ontoscope/login')
