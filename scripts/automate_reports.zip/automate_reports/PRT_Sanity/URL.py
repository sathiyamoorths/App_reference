import urllib.request
import time
timing=time.strftime("%Y-%m-%d %H.%M")
import ssl
ssl._create_default_https_context = ssl._create_unverified_context
def url_check():
    url_name=["PRT1","PRT2","PRT3"]
    url_list=["https://kosmos.internal.vodafone.com:8443","https://prtoolkit.direct.cwintra.com:8443","https://prtoolkit-proddataload.direct.cwintra.com:8443"]
    url_status=[]
    url_color=[]
    count=0
    for kosmos in url_list:
        out_code=urllib.request.urlopen(kosmos).getcode()
        if out_code==200:
            url_status.append("PASS")
            url_color.append("green")
        else:
            url_status.append("FAIL")
            url_color.append("red")
            count=count+1

    print(url_name)
    print(url_status)
    dictionary=dict(zip(url_name,url_status))
    print(dictionary)
    fout = "sanity.txt"
    fo = open(fout, "w")
    fo.write('TIME	 : '+ str(timing) + '\n')
    for k, v in dictionary.items():
        fo.write(str(k) + '     : '+ str(v) + '\n')
    fo.close()


url_check()
